import javax.swing.SwingUtilities;
import controller.LoginController;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginController loginController = new LoginController();
            loginController.mostrarLogin();
        });
    }
}