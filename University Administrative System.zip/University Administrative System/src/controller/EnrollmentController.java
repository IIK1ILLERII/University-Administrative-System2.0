package controller;

import model.Enrollment;
import model.Student;
import model.Subject;
import services.EnrollmentService;
import services.SectionService;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Optional;

public class EnrollmentController {
    private final EnrollmentService enrollmentService;
    private final SectionService sectionService;

    public EnrollmentController() {
        this.enrollmentService = new EnrollmentService();
        this.sectionService = new SectionService();
    }

    /**
     * Inscribe un estudiante en una materia usando el sistema automático de secciones
     */
    public boolean enrollStudent(int studentId, int subjectId, String semester) {
        return enrollmentService.enrollStudent(studentId, subjectId, semester);
    }

    /**
     * Inscribe un estudiante en una materia con profesor específico
     */
    public boolean enrollStudent(int studentId, int subjectId, int professorId, String semester) {
        return enrollmentService.enrollStudent(studentId, subjectId, professorId, semester);
    }

    /**
     * Inscribe un estudiante en una sección específica
     */
    public boolean enrollStudentInSection(int studentId, int sectionId, String semester) {
        return enrollmentService.enrollStudentInSpecificSection(studentId, sectionId, semester);
    }

    /**
     * Actualiza la calificación de una inscripción
     */
    public boolean updateGrade(int enrollmentId, double grade) {
        if (grade < 0 || grade > 100) {
            JOptionPane.showMessageDialog(null,
                    "La calificación debe estar entre 0 y 100",
                    "Error de Validación", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return enrollmentService.updateGrade(enrollmentId, grade);
    }

    /**
     * Da de baja una inscripción
     */
    public boolean dropEnrollment(int enrollmentId) {
        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de dar de baja esta inscripción?\n" +
                        "Esta acción cambiará el estado a 'DROPPED'.",
                "Confirmar Baja",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            return enrollmentService.dropEnrollment(enrollmentId);
        }
        return false;
    }

    /**
     * Carga todas las inscripciones en una tabla
     */
    public void loadEnrollmentsToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Enrollment> enrollments = enrollmentService.getAllEnrollments();
        for (Enrollment enrollment : enrollments) {
            model.addRow(createEnrollmentRow(enrollment));
        }
    }

    /**
     * Crea una fila de tabla para una inscripción
     */
    private Object[] createEnrollmentRow(Enrollment enrollment) {
        return new Object[]{
                enrollment.getEnrollmentId(),
                enrollment.getStudentName(),
                enrollment.getSubjectName(),
                enrollment.getProfessorName(),
                enrollment.getSectionCode() != null ? enrollment.getSectionCode() : "N/A",
                enrollment.getEnrollmentDate(),
                formatGrade(enrollment.getGrade()),
                getStatusWithIcon(enrollment.getStatus()),
                enrollment.getSemester()
        };
    }

    /**
     * Formatea la calificación para mostrar
     */
    private String formatGrade(Double grade) {
        if (grade == null) return "N/A";
        return String.format("%.2f", grade);
    }

    /**
     * Agrega iconos al estado para mejor visualización
     */
    private String getStatusWithIcon(String status) {
        switch (status.toUpperCase()) {
            case "ENROLLED": return "📝 " + status;
            case "PASSED": return "✅ " + status;
            case "FAILED": return "❌ " + status;
            case "DROPPED": return "🚪 " + status;
            default: return status;
        }
    }

    /**
     * Carga inscripciones filtradas por estudiante
     */
    public void loadEnrollmentsByStudentToTable(JTable table, int studentId) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Enrollment> enrollments = enrollmentService.getEnrollmentsByStudent(studentId);
        for (Enrollment enrollment : enrollments) {
            model.addRow(createEnrollmentRow(enrollment));
        }
    }

    /**
     * Carga inscripciones filtradas por materia
     */
    public void loadEnrollmentsBySubjectToTable(JTable table, int subjectId) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Enrollment> enrollments = enrollmentService.getEnrollmentsBySubject(subjectId);
        for (Enrollment enrollment : enrollments) {
            model.addRow(createEnrollmentRow(enrollment));
        }
    }

    /**
     * Carga inscripciones filtradas por semestre
     */
    public void loadEnrollmentsBySemesterToTable(JTable table, String semester) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Enrollment> enrollments = enrollmentService.getEnrollmentsBySemester(semester);
        for (Enrollment enrollment : enrollments) {
            model.addRow(createEnrollmentRow(enrollment));
        }
    }

    // ===== MÉTODOS DE CONSULTA Y ESTADÍSTICAS =====

    public int getTotalEnrollments() {
        return enrollmentService.countEnrollments();
    }

    public List<Enrollment> getActiveEnrollments() {
        return enrollmentService.getActiveEnrollments();
    }

    public List<Enrollment> getPassedEnrollments() {
        return enrollmentService.getPassedEnrollments();
    }

    public List<Enrollment> getFailedEnrollments() {
        return enrollmentService.getFailedEnrollments();
    }

    public List<Enrollment> getDroppedEnrollments() {
        return enrollmentService.getDroppedEnrollments();
    }

    public List<Enrollment> getEnrollmentsByStudent(int studentId) {
        return enrollmentService.getEnrollmentsByStudent(studentId);
    }

    public List<Enrollment> getEnrollmentsBySubject(int subjectId) {
        return enrollmentService.getEnrollmentsBySubject(subjectId);
    }

    public List<Enrollment> getEnrollmentsBySemester(String semester) {
        return enrollmentService.getEnrollmentsBySemester(semester);
    }

    public List<Enrollment> getEnrollmentsByProfessor(int professorId) {
        return enrollmentService.getEnrollmentsByProfessor(professorId);
    }

    public double getAverageGradeBySubject(int subjectId) {
        return enrollmentService.getAverageGradeBySubject(subjectId);
    }

    public int countActiveEnrollments() {
        return enrollmentService.countActiveEnrollments();
    }

    public int countEnrollmentsByStudent(int studentId) {
        return enrollmentService.countEnrollmentsByStudent(studentId);
    }

    public int countEnrollmentsBySubject(int subjectId) {
        return enrollmentService.countEnrollmentsBySubject(subjectId);
    }

    public double getStudentGPA(int studentId) {
        return enrollmentService.getStudentGPA(studentId);
    }

    public List<String> getAllSemesters() {
        return enrollmentService.getAllSemesters();
    }

    public Optional<Enrollment> getEnrollmentById(int id) {
        return enrollmentService.getEnrollmentById(id);
    }

    // ===== MÉTODOS PARA OBTENER DATOS PARA COMBOBOXES =====

    /**
     * Obtiene estudiantes activos para combobox
     */
    public List<Student> getActiveStudents() {
        // Este método debería implementarse en StudentService
        // Por ahora retornamos una lista vacía
        return List.of();
    }

    /**
     * Obtiene materias activas para combobox
     */
    public List<Subject> getActiveSubjects() {
        // Este método debería implementarse en SubjectService
        // Por ahora retornamos una lista vacía
        return List.of();
    }

    /**
     * Obtiene semestres disponibles
     */
    public String[] getSemesterOptions() {
        List<String> semesters = getAllSemesters();
        if (semesters.isEmpty()) {
            return new String[]{"2024-01", "2024-02", "2023-01", "2023-02"};
        }
        return semesters.toArray(new String[0]);
    }

    // ===== MÉTODOS DE VALIDACIÓN =====

    /**
     * Valida si un estudiante puede inscribirse en una materia
     */
    public boolean canEnrollStudent(int studentId, int subjectId) {
        // Verificar si ya está inscrito en la materia
        List<Enrollment> existingEnrollments = getEnrollmentsByStudent(studentId);
        boolean alreadyEnrolled = existingEnrollments.stream()
                .anyMatch(e -> e.getSubjectId() == subjectId &&
                        ("ENROLLED".equals(e.getStatus()) || "PASSED".equals(e.getStatus())));

        if (alreadyEnrolled) {
            JOptionPane.showMessageDialog(null,
                    "El estudiante ya está inscrito o ha aprobado esta materia",
                    "Inscripción Duplicada", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return true;
    }

    /**
     * Obtiene estadísticas de inscripciones
     */
    public String getEnrollmentStatistics() {
        int total = getTotalEnrollments();
        int active = countActiveEnrollments();
        int passed = getPassedEnrollments().size();
        int failed = getFailedEnrollments().size();
        int dropped = getDroppedEnrollments().size();

        return String.format(
                "Total: %d | Activas: %d | Aprobadas: %d | Reprobadas: %d | Bajas: %d",
                total, active, passed, failed, dropped
        );
    }

    /**
     * Obtiene el progreso académico de un estudiante
     */
    public String getStudentProgress(int studentId) {
        List<Enrollment> enrollments = getEnrollmentsByStudent(studentId);
        long total = enrollments.size();
        long passed = enrollments.stream().filter(e -> "PASSED".equals(e.getStatus())).count();
        long enrolled = enrollments.stream().filter(e -> "ENROLLED".equals(e.getStatus())).count();
        double gpa = getStudentGPA(studentId);

        return String.format(
                "Materias: %d | Aprobadas: %d | En curso: %d | GPA: %.2f",
                total, passed, enrolled, gpa
        );
    }

    /**
     * Actualiza el estado de una inscripción
     */
    public boolean updateStatus(int enrollmentId, String status) {
        return enrollmentService.updateStatus(enrollmentId, status);
    }

    /**
     * Obtiene inscripciones por sección
     */
    public List<Enrollment> getEnrollmentsBySection(int sectionId) {
        return enrollmentService.getEnrollmentsBySection(sectionId);
    }
}