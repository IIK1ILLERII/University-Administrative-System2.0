package controller;

import views.LoginDialog;
import views.MainWindow;
import service.AuthService;
import model.User;
import javax.swing.*;

public class LoginController {
    private AuthService authService;

    public LoginController() {
        this.authService = new AuthService();
    }

    public void mostrarLogin() {
        LoginDialog loginDialog = new LoginDialog(null);
        loginDialog.setVisible(true);

        if (loginDialog.isAuthenticated()) {
            String username = loginDialog.getUsername();
            String password = loginDialog.getPassword();

            if (authService.autenticar(username, password)) {
                User user = authService.getCurrentUser();
                abrirMainWindow(user);
            } else {
                JOptionPane.showMessageDialog(null,
                        "Usuario o contraseña incorrectos",
                        "Error de autenticación",
                        JOptionPane.ERROR_MESSAGE);
                mostrarLogin(); // Reintentar
            }
        } else {
            System.exit(0); // Salir si cancela el login
        }
    }

    private void abrirMainWindow(User user) {
        MainWindow mainWindow = new MainWindow(user);
        mainWindow.setVisible(true);
    }
}