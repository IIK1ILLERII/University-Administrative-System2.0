package controller;

import model.Professor;
import services.ProfessorService;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Optional;

public class ProfessorController {
    private final ProfessorService professorService;

    public ProfessorController() {
        this.professorService = new ProfessorService();
    }

    // Método original para compatibilidad
    public boolean addProfessor(String firstName, String lastName, String email,
                                String phone, String department, String specialty,
                                double salary) {
        Professor professor = new Professor();
        professor.setFirstName(firstName);
        // Dividir el apellido en paterno y materno (asumiendo que viene completo)
        String[] lastNames = lastName.split(" ");
        professor.setPaternalLastName(lastNames.length > 0 ? lastNames[0] : "");
        professor.setMaternalLastName(lastNames.length > 1 ? lastNames[1] : "");
        professor.setEmail(email);
        professor.setPhone(phone);
        professor.setDepartment(department);
        professor.setSpecialty(specialty);
        professor.setFixedSalary(salary);
        professor.setProfessorType("TIEMPO_COMPLETO");

        return professorService.addProfessor(professor);
    }

    // Nuevo método completo
    public boolean addProfessor(String firstName, String paternalLastName, String maternalLastName,
                                String email, String phone, String dni, String gender, int age,
                                String district, String department, String specialty,
                                String professorType, double fixedSalary, int hoursPerWeek,
                                double hourlyRate, String status) {
        Professor professor = new Professor();
        professor.setFirstName(firstName);
        professor.setPaternalLastName(paternalLastName);
        professor.setMaternalLastName(maternalLastName);
        professor.setEmail(email);
        professor.setPhone(phone);
        professor.setDni(dni);
        professor.setGender(gender);
        professor.setAge(age);
        professor.setDistrict(district);
        professor.setDepartment(department);
        professor.setSpecialty(specialty);
        professor.setProfessorType(professorType);
        professor.setFixedSalary(fixedSalary);
        professor.setHoursPerWeek(hoursPerWeek);
        professor.setHourlyRate(hourlyRate);
        professor.setStatus(status);

        return professorService.addProfessor(professor);
    }

    // Método original para compatibilidad
    public boolean updateProfessor(int professorId, String firstName, String lastName,
                                   String email, String phone, String department,
                                   String specialty, double salary, String status) {
        Professor professor = new Professor();
        professor.setProfessorId(professorId);
        professor.setFirstName(firstName);
        // Dividir el apellido en paterno y materno
        String[] lastNames = lastName.split(" ");
        professor.setPaternalLastName(lastNames.length > 0 ? lastNames[0] : "");
        professor.setMaternalLastName(lastNames.length > 1 ? lastNames[1] : "");
        professor.setEmail(email);
        professor.setPhone(phone);
        professor.setDepartment(department);
        professor.setSpecialty(specialty);
        professor.setFixedSalary(salary);
        professor.setStatus(status);

        return professorService.updateProfessor(professor);
    }

    // Nuevo método completo
    public boolean updateProfessor(int professorId, String firstName, String paternalLastName,
                                   String maternalLastName, String email, String phone, String dni,
                                   String gender, int age, String district, String department,
                                   String specialty, String professorType, double fixedSalary,
                                   int hoursPerWeek, double hourlyRate, String status) {
        Professor professor = new Professor();
        professor.setProfessorId(professorId);
        professor.setFirstName(firstName);
        professor.setPaternalLastName(paternalLastName);
        professor.setMaternalLastName(maternalLastName);
        professor.setEmail(email);
        professor.setPhone(phone);
        professor.setDni(dni);
        professor.setGender(gender);
        professor.setAge(age);
        professor.setDistrict(district);
        professor.setDepartment(department);
        professor.setSpecialty(specialty);
        professor.setProfessorType(professorType);
        professor.setFixedSalary(fixedSalary);
        professor.setHoursPerWeek(hoursPerWeek);
        professor.setHourlyRate(hourlyRate);
        professor.setStatus(status);

        return professorService.updateProfessor(professor);
    }

    public boolean deleteProfessor(int professorId) {
        return professorService.deleteProfessor(professorId);
    }

    public void loadProfessorsToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Professor> professors = professorService.getAllProfessors();
        for (Professor professor : professors) {
            model.addRow(new Object[]{
                    professor.getProfessorId(),
                    professor.getFirstName(),
                    professor.getLastName(), // Método de compatibilidad
                    professor.getEmail(),
                    professor.getPhone(),
                    professor.getDepartment(),
                    professor.getSpecialty(),
                    professor.getSalary(),
                    professor.getStatus()
            });
        }
    }

    public Optional<Professor> getProfessorById(int id) {
        return professorService.getProfessorById(id);
    }

    public List<Professor> getProfessorsByDepartment(String department) {
        return professorService.getProfessorsByDepartment(department);
    }

    public List<Professor> getProfessorsByType(String professorType) {
        return professorService.getProfessorsByType(professorType);
    }

    public List<Professor> searchProfessors(String criteria, String searchType) {
        return professorService.searchProfessors(criteria, searchType);
    }

    public int getTotalProfessors() {
        return professorService.countProfessors();
    }

    public int getProfessorsCountByType(String professorType) {
        return professorService.countProfessorsByType(professorType);
    }
}