package controller;

import model.Section;
import model.SectionSchedule;
import services.SectionService;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Optional;

public class SectionController {
    private final SectionService sectionService;

    public SectionController() {
        this.sectionService = new SectionService();
    }

    public Optional<Section> enrollStudentInSubject(int studentId, int subjectId) {
        return sectionService.enrollStudentInSubject(studentId, subjectId);
    }

    public boolean createSection(int subjectId, String sectionCode, int professorId, int capacity) {
        Section section = new Section();
        section.setSubjectId(subjectId);
        section.setSectionCode(sectionCode);
        section.setProfessorId(professorId);
        section.setCapacity(capacity);

        return sectionService.createSection(section);
    }

    public boolean updateSection(int sectionId, int subjectId, String sectionCode,
                                 int professorId, int capacity, int currentEnrollment, String status) {
        Section section = new Section();
        section.setSectionId(sectionId);
        section.setSubjectId(subjectId);
        section.setSectionCode(sectionCode);
        section.setProfessorId(professorId);
        section.setCapacity(capacity);
        section.setCurrentEnrollment(currentEnrollment);
        section.setStatus(status);

        return sectionService.updateSection(section);
    }

    public boolean deleteSection(int sectionId) {
        return sectionService.deleteSection(sectionId);
    }

    public boolean addScheduleToSection(int sectionId, String dayOfWeek,
                                        String startTime, String endTime, String classroom) {
        SectionSchedule schedule = new SectionSchedule();
        schedule.setSectionId(sectionId);
        schedule.setDayOfWeek(dayOfWeek);
        schedule.setStartTime(startTime);
        schedule.setEndTime(endTime);
        schedule.setClassroom(classroom);

        return sectionService.addScheduleToSection(schedule);
    }

    public void loadSectionsToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Section> sections = getAllSections();
        for (Section section : sections) {
            model.addRow(new Object[]{
                    section.getSectionId(),
                    section.getFullSectionCode(),
                    section.getSubjectName(),
                    section.getProfessorName(),
                    section.getCurrentEnrollment() + "/" + section.getCapacity(),
                    section.getScheduleSummary(),
                    section.getStatus()
            });
        }
    }

    public void loadSectionDetailsToTable(JTable table, int sectionId) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        Optional<Section> sectionOpt = sectionService.getSectionById(sectionId);
        if (sectionOpt.isPresent()) {
            Section section = sectionOpt.get();
            for (SectionSchedule schedule : section.getSchedules()) {
                model.addRow(new Object[]{
                        schedule.getDayOfWeek(),
                        schedule.getTimeRange(),
                        schedule.getClassroom()
                });
            }
        }
    }

    public void loadEnrolledStudentsToTable(JTable table, int sectionId) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        Optional<Section> sectionOpt = sectionService.getSectionById(sectionId);
        if (sectionOpt.isPresent()) {
            Section section = sectionOpt.get();
            for (var student : section.getEnrolledStudents()) {
                model.addRow(new Object[]{
                        student.getStudentId(),
                        student.getFirstName() + " " + student.getLastName(),
                        student.getEmail(),
                        student.getCareer(),
                        student.getSemester() + "º semestre"
                });
            }
        }
    }

    public Optional<Section> getSectionById(int id) {
        return sectionService.getSectionById(id);
    }

    public List<Section> getSectionsBySubject(int subjectId) {
        return sectionService.getSectionsBySubject(subjectId);
    }

    public List<Section> getSectionsByProfessor(int professorId) {
        return sectionService.getSectionsByProfessor(professorId);
    }

    /**
     * Obtiene todas las secciones
     */
    public List<Section> getAllSections() {
        return sectionService.getAllSections();
    }

    public int getTotalSections() {
        return sectionService.countSections();
    }

    public int getSectionsCountBySubject(int subjectId) {
        return sectionService.countSectionsBySubject(subjectId);
    }
}