package controller;

import model.Student;
import services.StudentService;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Optional;

public class StudentController {
    private final StudentService studentService;

    public StudentController() {
        this.studentService = new StudentService();
    }

    // Método actualizado para agregar estudiante con nuevos campos
    public boolean addStudent(String dni, String firstName, String lastName1, String lastName2,
                              int age, String gender, String email, String phone,
                              String address, String district, String career, int semester,
                              String dateOfBirth, double gpa) {
        Student student = new Student();
        student.setDni(dni);
        student.setFirstName(firstName);
        student.setLastName1(lastName1);
        student.setLastName2(lastName2);
        student.setAge(age);
        student.setGender(gender);
        student.setEmail(email);
        student.setPhone(phone);
        student.setAddress(address);
        student.setDistrict(district);
        student.setCareer(career);
        student.setSemester(semester);
        student.setDateOfBirth(dateOfBirth);
        student.setGpa(gpa);

        return studentService.addStudent(student);
    }

    // Método actualizado para editar estudiante con nuevos campos
    public boolean updateStudent(int studentId, String dni, String firstName, String lastName1,
                                 String lastName2, int age, String gender, String email,
                                 String phone, String address, String district, String career,
                                 int semester, String dateOfBirth, double gpa, String status) {
        Student student = new Student();
        student.setStudentId(studentId);
        student.setDni(dni);
        student.setFirstName(firstName);
        student.setLastName1(lastName1);
        student.setLastName2(lastName2);
        student.setAge(age);
        student.setGender(gender);
        student.setEmail(email);
        student.setPhone(phone);
        student.setAddress(address);
        student.setDistrict(district);
        student.setCareer(career);
        student.setSemester(semester);
        student.setDateOfBirth(dateOfBirth);
        student.setGpa(gpa);
        student.setStatus(status);

        return studentService.updateStudent(student);
    }

    // Método sobrecargado para mantener compatibilidad (si es necesario)
    public boolean updateStudent(int studentId, String firstName, String lastName,
                                 String email, String phone, String career,
                                 int semester, String dateOfBirth, double gpa, String status) {
        Student student = new Student();
        student.setStudentId(studentId);
        student.setFirstName(firstName);
        student.setLastName1(lastName); // Asignar a lastName1 para compatibilidad
        student.setEmail(email);
        student.setPhone(phone);
        student.setCareer(career);
        student.setSemester(semester);
        student.setDateOfBirth(dateOfBirth);
        student.setGpa(gpa);
        student.setStatus(status);

        return studentService.updateStudent(student);
    }

    public boolean deleteStudent(int studentId) {
        return studentService.deleteStudent(studentId);
    }

    public void loadStudentsToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Student> students = studentService.getAllStudents();
        for (Student student : students) {
            model.addRow(new Object[]{
                    student.getStudentId(),
                    student.getDni(),
                    student.getFirstName(),
                    student.getLastName1(),
                    student.getLastName2(),
                    student.getAge(),
                    student.getGender(),
                    student.getEmail(),
                    student.getPhone(),
                    student.getAddress(),
                    student.getDistrict(),
                    student.getCareer(),
                    student.getSemester(),
                    String.format("%.2f", student.getGpa()),
                    student.getEnrollmentDate(),
                    student.getStatus()
            });
        }
    }

    public Optional<Student> getStudentById(int id) {
        return studentService.getStudentById(id);
    }

    public List<Student> searchStudents(String criteria, String searchType) {
        switch (searchType.toUpperCase()) {
            case "NAME":
                return studentService.getStudentsByName(criteria);
            case "LAST_NAME1":
                return studentService.getStudentsByLastName1(criteria);
            case "LAST_NAME2":
                return studentService.getStudentsByLastName2(criteria);
            case "DNI":
                return studentService.getStudentByDni(criteria)
                        .map(List::of)
                        .orElse(List.of());
            case "CAREER":
                return studentService.getStudentsByCareer(criteria);
            case "EMAIL":
                return studentService.getStudentByEmail(criteria)
                        .map(List::of)
                        .orElse(List.of());
            case "SEMESTER":
                try {
                    int semester = Integer.parseInt(criteria);
                    return studentService.getStudentsBySemester(semester);
                } catch (NumberFormatException e) {
                    return List.of();
                }
            case "DISTRICT":
                return studentService.getStudentsByDistrict(criteria);
            case "GENDER":
                return studentService.getStudentsByGender(criteria);
            default:
                return studentService.getAllStudents();
        }
    }

    public int getTotalStudents() {
        return studentService.countStudents();
    }

    public List<Student> getActiveStudents() {
        return studentService.getActiveStudents();
    }

    // Métodos adicionales para estadísticas
    public long getStudentsCountByGender(String gender) {
        return studentService.getStudentsCountByGender(gender);
    }

    public List<String> getDistricts() {
        return studentService.getDistricts();
    }

    public long getStudentsCountByDistrict(String district) {
        return studentService.getStudentsCountByDistrict(district);
    }
}