package controller;

import model.Subject;
import model.ClassSchedule;
import services.SubjectService;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import java.util.List;
import java.util.Optional;

public class SubjectController {
    private final SubjectService subjectService;

    public SubjectController() {
        this.subjectService = new SubjectService();
    }

    public boolean addSubject(String subjectName, String code, int credits,
                              int professorId, String department,
                              String difficultyLevel, int hoursPerWeek) {
        Subject subject = new Subject();
        subject.setSubjectName(subjectName);
        subject.setCode(code);
        subject.setCredits(credits);
        subject.setProfessorId(professorId);
        subject.setDepartment(department);
        subject.setDifficultyLevel(difficultyLevel);
        subject.setHoursPerWeek(hoursPerWeek);

        return subjectService.addSubject(subject);
    }

    public boolean updateSubject(int subjectId, String subjectName, String code,
                                 int credits, int professorId, String department,
                                 String difficultyLevel, int hoursPerWeek) {
        Subject subject = new Subject();
        subject.setSubjectId(subjectId);
        subject.setSubjectName(subjectName);
        subject.setCode(code);
        subject.setCredits(credits);
        subject.setProfessorId(professorId);
        subject.setDepartment(department);
        subject.setDifficultyLevel(difficultyLevel);
        subject.setHoursPerWeek(hoursPerWeek);

        return subjectService.updateSubject(subject);
    }

    public boolean deleteSubject(int subjectId) {
        return subjectService.deleteSubject(subjectId);
    }

    // Métodos para horarios
    public boolean addSchedule(int subjectId, int professorId, String dayOfWeek,
                               String startTime, String endTime, String classroom) {
        ClassSchedule schedule = new ClassSchedule();
        schedule.setSubjectId(subjectId);
        schedule.setProfessorId(professorId);
        schedule.setDayOfWeek(dayOfWeek);
        schedule.setStartTime(startTime);
        schedule.setEndTime(endTime);
        schedule.setClassroom(classroom);

        return subjectService.addSchedule(schedule);
    }

    public boolean updateSchedule(int scheduleId, int subjectId, int professorId,
                                  String dayOfWeek, String startTime, String endTime,
                                  String classroom, String status) {
        ClassSchedule schedule = new ClassSchedule();
        schedule.setScheduleId(scheduleId);
        schedule.setSubjectId(subjectId);
        schedule.setProfessorId(professorId);
        schedule.setDayOfWeek(dayOfWeek);
        schedule.setStartTime(startTime);
        schedule.setEndTime(endTime);
        schedule.setClassroom(classroom);
        schedule.setStatus(status);

        return subjectService.updateSchedule(schedule);
    }

    public boolean deleteSchedule(int scheduleId) {
        return subjectService.deleteSchedule(scheduleId);
    }

    public void loadSubjectsToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<Subject> subjects = subjectService.getAllSubjects();
        for (Subject subject : subjects) {
            model.addRow(new Object[]{
                    subject.getSubjectId(),
                    subject.getCode(),
                    subject.getSubjectName(),
                    subject.getCredits(),
                    subject.getProfessorName(),
                    subject.getDepartment(),
                    subject.getDifficultyLevel(),
                    subject.getHoursPerWeek(),
                    subject.getScheduleSummary()
            });
        }
    }

    public void loadSchedulesToTable(JTable table) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<ClassSchedule> schedules = subjectService.getWeeklySchedule();
        for (ClassSchedule schedule : schedules) {
            model.addRow(new Object[]{
                    schedule.getScheduleId(),
                    schedule.getSubjectCode(),
                    schedule.getSubjectName(),
                    schedule.getProfessorName(),
                    schedule.getDayOfWeek(),
                    schedule.getTimeRange(),
                    schedule.getClassroom(),
                    schedule.getStatus()
            });
        }
    }

    public void loadSchedulesBySubjectToTable(JTable table, int subjectId) {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        List<ClassSchedule> schedules = subjectService.getSchedulesBySubject(subjectId);
        for (ClassSchedule schedule : schedules) {
            model.addRow(new Object[]{
                    schedule.getScheduleId(),
                    schedule.getDayOfWeek(),
                    schedule.getTimeRange(),
                    schedule.getClassroom(),
                    schedule.getProfessorName(),
                    schedule.getStatus()
            });
        }
    }

    public Optional<Subject> getSubjectById(int id) {
        return subjectService.getSubjectById(id);
    }

    public Optional<ClassSchedule> getScheduleById(int scheduleId) {
        return subjectService.getScheduleById(scheduleId);
    }

    public List<Subject> getSubjectsByProfessor(int professorId) {
        return subjectService.getSubjectsByProfessor(professorId);
    }

    public List<Subject> getSubjectsByDepartment(String department) {
        return subjectService.getSubjectsByDepartment(department);
    }

    public List<ClassSchedule> getSchedulesBySubject(int subjectId) {
        return subjectService.getSchedulesBySubject(subjectId);
    }

    public List<ClassSchedule> getSchedulesByProfessor(int professorId) {
        return subjectService.getSchedulesByProfessor(professorId);
    }

    public List<ClassSchedule> getWeeklySchedule() {
        return subjectService.getWeeklySchedule();
    }

    public List<ClassSchedule> getSchedulesByDay(String dayOfWeek) {
        return subjectService.getSchedulesByDay(dayOfWeek);
    }

    public List<Subject> getBasicSubjects() {
        return subjectService.getBasicSubjects();
    }

    public List<Subject> getIntermediateSubjects() {
        return subjectService.getIntermediateSubjects();
    }

    public List<Subject> getAllActiveSubjects() {
        return subjectService.getAllActiveSubjects();
    }

    public List<Subject> getAdvancedSubjects() {
        return subjectService.getAdvancedSubjects();
    }

    public int getTotalSubjects() {
        return subjectService.countSubjects();
    }

    public int getTotalSchedules() {
        return subjectService.countActiveSchedules();
    }

    public List<String> getDaysOfWeek() {
        return subjectService.getDaysOfWeek();
    }

    public List<String> getTimeSlots() {
        return subjectService.getTimeSlots();
    }
}