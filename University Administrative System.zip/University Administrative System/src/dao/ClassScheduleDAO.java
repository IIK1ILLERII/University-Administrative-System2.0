package dao;

import model.ClassSchedule;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ClassScheduleDAO implements DAO<ClassSchedule> {
    private final Connection connection;

    public ClassScheduleDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Optional<ClassSchedule> get(int id) {
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "WHERE cs.schedule_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? Optional.of(mapResultSetToSchedule(rs)) : Optional.empty();
        } catch (SQLException e) {
            handleException("get schedule by ID", e);
            return Optional.empty();
        }
    }

    @Override
    public List<ClassSchedule> getAll() {
        List<ClassSchedule> schedules = new ArrayList<>();
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "ORDER BY cs.day_of_week, cs.start_time";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get all schedules", e);
        }
        return schedules;
    }

    @Override
    public boolean save(ClassSchedule schedule) {
        String sql = "INSERT INTO class_schedules (subject_id, professor_id, day_of_week, " +
                "start_time, end_time, classroom) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"schedule_id"})) {
            pstmt.setInt(1, schedule.getSubjectId());
            pstmt.setInt(2, schedule.getProfessorId());
            pstmt.setString(3, schedule.getDayOfWeek());
            pstmt.setString(4, schedule.getStartTime());
            pstmt.setString(5, schedule.getEndTime());
            pstmt.setString(6, schedule.getClassroom());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        schedule.setScheduleId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            handleException("save schedule", e);
            return false;
        }
    }

    @Override
    public boolean update(ClassSchedule schedule) {
        String sql = "UPDATE class_schedules SET subject_id = ?, professor_id = ?, day_of_week = ?, " +
                "start_time = ?, end_time = ?, classroom = ?, status = ? WHERE schedule_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, schedule.getSubjectId());
            pstmt.setInt(2, schedule.getProfessorId());
            pstmt.setString(3, schedule.getDayOfWeek());
            pstmt.setString(4, schedule.getStartTime());
            pstmt.setString(5, schedule.getEndTime());
            pstmt.setString(6, schedule.getClassroom());
            pstmt.setString(7, schedule.getStatus());
            pstmt.setInt(8, schedule.getScheduleId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("update schedule", e);
            return false;
        }
    }

    @Override
    public boolean delete(ClassSchedule schedule) {
        return deleteById(schedule.getScheduleId());
    }

    @Override
    public boolean deleteById(int id) {
        String sql = "DELETE FROM class_schedules WHERE schedule_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("delete schedule", e);
            return false;
        }
    }

    @Override
    public int count() {
        String sql = "SELECT COUNT(*) FROM class_schedules WHERE status = 'ACTIVE'";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            handleException("count schedules", e);
            return 0;
        }
    }

    @Override
    public boolean exists(int id) {
        return get(id).isPresent();
    }

    public List<ClassSchedule> getBySubject(int subjectId) {
        List<ClassSchedule> schedules = new ArrayList<>();
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "WHERE cs.subject_id = ? ORDER BY cs.day_of_week, cs.start_time";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, subjectId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get schedules by subject", e);
        }
        return schedules;
    }

    public List<ClassSchedule> getByProfessor(int professorId) {
        List<ClassSchedule> schedules = new ArrayList<>();
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "WHERE cs.professor_id = ? ORDER BY cs.day_of_week, cs.start_time";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, professorId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get schedules by professor", e);
        }
        return schedules;
    }

    public List<ClassSchedule> getByDayOfWeek(String dayOfWeek) {
        List<ClassSchedule> schedules = new ArrayList<>();
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "WHERE cs.day_of_week = ? ORDER BY cs.start_time";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, dayOfWeek);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get schedules by day", e);
        }
        return schedules;
    }

    public List<ClassSchedule> getWeeklySchedule() {
        List<ClassSchedule> schedules = new ArrayList<>();
        String sql = "SELECT cs.*, s.subject_name, s.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM class_schedules cs " +
                "JOIN subjects s ON cs.subject_id = s.subject_id " +
                "JOIN professors p ON cs.professor_id = p.professor_id " +
                "WHERE cs.status = 'ACTIVE' " +
                "ORDER BY " +
                "CASE cs.day_of_week " +
                "  WHEN 'LUNES' THEN 1 " +
                "  WHEN 'MARTES' THEN 2 " +
                "  WHEN 'MIERCOLES' THEN 3 " +
                "  WHEN 'JUEVES' THEN 4 " +
                "  WHEN 'VIERNES' THEN 5 " +
                "  WHEN 'SABADO' THEN 6 " +
                "END, cs.start_time";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get weekly schedule", e);
        }
        return schedules;
    }

    public boolean hasTimeConflict(int professorId, String dayOfWeek, String startTime, String endTime, Integer excludeScheduleId) {
        String sql = "SELECT COUNT(*) FROM class_schedules " +
                "WHERE professor_id = ? AND day_of_week = ? AND status = 'ACTIVE' " +
                "AND ((start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?) OR (start_time >= ? AND start_time < ?))";

        if (excludeScheduleId != null) {
            sql += " AND schedule_id != ?";
        }

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            int paramIndex = 1;
            pstmt.setInt(paramIndex++, professorId);
            pstmt.setString(paramIndex++, dayOfWeek);
            pstmt.setString(paramIndex++, endTime);
            pstmt.setString(paramIndex++, startTime);
            pstmt.setString(paramIndex++, endTime);
            pstmt.setString(paramIndex++, startTime);
            pstmt.setString(paramIndex++, startTime);
            pstmt.setString(paramIndex++, endTime);

            if (excludeScheduleId != null) {
                pstmt.setInt(paramIndex, excludeScheduleId);
            }

            ResultSet rs = pstmt.executeQuery();
            return rs.next() && rs.getInt(1) > 0;
        } catch (SQLException e) {
            handleException("check time conflict", e);
            return true; // En caso de error, asumir que hay conflicto
        }
    }

    private ClassSchedule mapResultSetToSchedule(ResultSet rs) throws SQLException {
        ClassSchedule schedule = new ClassSchedule();
        schedule.setScheduleId(rs.getInt("schedule_id"));
        schedule.setSubjectId(rs.getInt("subject_id"));
        schedule.setProfessorId(rs.getInt("professor_id"));
        schedule.setDayOfWeek(rs.getString("day_of_week"));
        schedule.setStartTime(rs.getString("start_time"));
        schedule.setEndTime(rs.getString("end_time"));
        schedule.setClassroom(rs.getString("classroom"));
        schedule.setStatus(rs.getString("status"));
        schedule.setSubjectName(rs.getString("subject_name"));
        schedule.setProfessorName(rs.getString("professor_name"));
        schedule.setSubjectCode(rs.getString("subject_code"));
        return schedule;
    }

    private void handleException(String operation, SQLException e) {
        System.err.println("Error during " + operation + ": " + e.getMessage());
        e.printStackTrace();
    }
}