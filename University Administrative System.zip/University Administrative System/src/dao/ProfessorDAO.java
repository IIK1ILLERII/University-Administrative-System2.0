package dao;

import model.Professor;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class ProfessorDAO implements DAO<Professor> {
    private final Connection connection;

    public ProfessorDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Optional<Professor> get(int id) {
        String sql = "SELECT * FROM professors WHERE professor_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? Optional.of(mapResultSetToProfessor(rs)) : Optional.empty();
        } catch (SQLException e) {
            handleException("get professor by ID", e);
            return Optional.empty();
        }
    }

    @Override
    public List<Professor> getAll() {
        List<Professor> professors = new ArrayList<>();
        String sql = "SELECT * FROM professors ORDER BY professor_id";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                professors.add(mapResultSetToProfessor(rs));
            }
        } catch (SQLException e) {
            handleException("get all professors", e);
        }
        return professors;
    }

    @Override
    public boolean save(Professor professor) {
        String sql = "INSERT INTO professors (" +
                "professor_id, first_name, paternal_last_name, maternal_last_name, " +
                "email, phone, dni, gender, age, district, department, specialty, " +
                "professor_type, fixed_salary, hours_per_week, hourly_rate, status" +
                ") VALUES (seq_professors.NEXTVAL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"professor_id"})) {
            setProfessorParameters(pstmt, professor);
            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        professor.setProfessorId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            handleException("save professor", e);
            return false;
        }
    }

    @Override
    public boolean update(Professor professor) {
        String sql = "UPDATE professors SET " +
                "first_name = ?, paternal_last_name = ?, maternal_last_name = ?, " +
                "email = ?, phone = ?, dni = ?, gender = ?, age = ?, district = ?, " +
                "department = ?, specialty = ?, professor_type = ?, fixed_salary = ?, " +
                "hours_per_week = ?, hourly_rate = ?, status = ? " +
                "WHERE professor_id = ?";

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, professor.getFirstName());
            pstmt.setString(2, professor.getPaternalLastName());
            pstmt.setString(3, professor.getMaternalLastName());
            pstmt.setString(4, professor.getEmail());
            pstmt.setString(5, professor.getPhone());
            pstmt.setString(6, professor.getDni());
            pstmt.setString(7, professor.getGender());
            pstmt.setInt(8, professor.getAge());
            pstmt.setString(9, professor.getDistrict());
            pstmt.setString(10, professor.getDepartment());
            pstmt.setString(11, professor.getSpecialty());
            pstmt.setString(12, professor.getProfessorType());
            pstmt.setDouble(13, professor.getFixedSalary());
            pstmt.setInt(14, professor.getHoursPerWeek());
            pstmt.setDouble(15, professor.getHourlyRate());
            pstmt.setString(16, professor.getStatus());
            pstmt.setInt(17, professor.getProfessorId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("update professor", e);
            return false;
        }
    }

    @Override
    public boolean delete(Professor professor) {
        return deleteById(professor.getProfessorId());
    }

    @Override
    public boolean deleteById(int id) {
        String sql = "DELETE FROM professors WHERE professor_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("delete professor", e);
            return false;
        }
    }

    @Override
    public int count() {
        String sql = "SELECT COUNT(*) FROM professors";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            handleException("count professors", e);
            return 0;
        }
    }

    @Override
    public boolean exists(int id) {
        return get(id).isPresent();
    }

    public Optional<Professor> getByEmail(String email) {
        String sql = "SELECT * FROM professors WHERE email = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? Optional.of(mapResultSetToProfessor(rs)) : Optional.empty();
        } catch (SQLException e) {
            handleException("get professor by email", e);
            return Optional.empty();
        }
    }

    public Optional<Professor> getByDni(String dni) {
        String sql = "SELECT * FROM professors WHERE dni = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, dni);
            ResultSet rs = pstmt.executeQuery();
            return rs.next() ? Optional.of(mapResultSetToProfessor(rs)) : Optional.empty();
        } catch (SQLException e) {
            handleException("get professor by DNI", e);
            return Optional.empty();
        }
    }

    public List<Professor> getByDepartment(String department) {
        List<Professor> professors = new ArrayList<>();
        String sql = "SELECT * FROM professors WHERE UPPER(department) LIKE ? ORDER BY paternal_last_name, maternal_last_name, first_name";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, "%" + department.toUpperCase() + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                professors.add(mapResultSetToProfessor(rs));
            }
        } catch (SQLException e) {
            handleException("get professors by department", e);
        }
        return professors;
    }

    public List<Professor> getByType(String professorType) {
        List<Professor> professors = new ArrayList<>();
        String sql = "SELECT * FROM professors WHERE professor_type = ? ORDER BY paternal_last_name, maternal_last_name, first_name";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, professorType);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                professors.add(mapResultSetToProfessor(rs));
            }
        } catch (SQLException e) {
            handleException("get professors by type", e);
        }
        return professors;
    }

    public List<Professor> getByStatus(String status) {
        List<Professor> professors = new ArrayList<>();
        String sql = "SELECT * FROM professors WHERE status = ? ORDER BY paternal_last_name, maternal_last_name, first_name";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, status);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                professors.add(mapResultSetToProfessor(rs));
            }
        } catch (SQLException e) {
            handleException("get professors by status", e);
        }
        return professors;
    }

    public List<Professor> getActiveProfessors() {
        return getByStatus("ACTIVE");
    }

    public List<Professor> search(String criteria, String searchType) {
        List<Professor> professors = new ArrayList<>();
        String sql = buildSearchQuery(searchType);

        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, "%" + criteria.toUpperCase() + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                professors.add(mapResultSetToProfessor(rs));
            }
        } catch (SQLException e) {
            handleException("search professors", e);
        }
        return professors;
    }

    private String buildSearchQuery(String searchType) {
        switch (searchType) {
            case "Nombre":
                return "SELECT * FROM professors WHERE UPPER(first_name) LIKE ? ORDER BY paternal_last_name, maternal_last_name, first_name";
            case "Apellido Paterno":
                return "SELECT * FROM professors WHERE UPPER(paternal_last_name) LIKE ? ORDER BY paternal_last_name, maternal_last_name, first_name";
            case "Departamento":
                return "SELECT * FROM professors WHERE UPPER(department) LIKE ? ORDER BY department, paternal_last_name, maternal_last_name";
            case "DNI":
                return "SELECT * FROM professors WHERE dni LIKE ? ORDER BY paternal_last_name, maternal_last_name, first_name";
            default:
                return "SELECT * FROM professors WHERE UPPER(first_name) LIKE ? OR UPPER(paternal_last_name) LIKE ? OR UPPER(maternal_last_name) LIKE ? ORDER BY paternal_last_name, maternal_last_name, first_name";
        }
    }

    private Professor mapResultSetToProfessor(ResultSet rs) throws SQLException {
        Professor professor = new Professor();
        professor.setProfessorId(rs.getInt("professor_id"));
        professor.setFirstName(rs.getString("first_name"));
        professor.setPaternalLastName(rs.getString("paternal_last_name"));
        professor.setMaternalLastName(rs.getString("maternal_last_name"));
        professor.setEmail(rs.getString("email"));
        professor.setPhone(rs.getString("phone"));
        professor.setDni(rs.getString("dni"));
        professor.setGender(rs.getString("gender"));
        professor.setAge(rs.getInt("age"));
        professor.setDistrict(rs.getString("district"));
        professor.setDepartment(rs.getString("department"));
        professor.setSpecialty(rs.getString("specialty"));
        professor.setProfessorType(rs.getString("professor_type"));
        professor.setFixedSalary(rs.getDouble("fixed_salary"));
        professor.setHoursPerWeek(rs.getInt("hours_per_week"));
        professor.setHourlyRate(rs.getDouble("hourly_rate"));
        professor.setStatus(rs.getString("status"));

        return professor;
    }

    private void setProfessorParameters(PreparedStatement pstmt, Professor professor) throws SQLException {
        pstmt.setString(1, professor.getFirstName());
        pstmt.setString(2, professor.getPaternalLastName());
        pstmt.setString(3, professor.getMaternalLastName());
        pstmt.setString(4, professor.getEmail());
        pstmt.setString(5, professor.getPhone());
        pstmt.setString(6, professor.getDni());
        pstmt.setString(7, professor.getGender());
        pstmt.setInt(8, professor.getAge());
        pstmt.setString(9, professor.getDistrict());
        pstmt.setString(10, professor.getDepartment());
        pstmt.setString(11, professor.getSpecialty());
        pstmt.setString(12, professor.getProfessorType());
        pstmt.setDouble(13, professor.getFixedSalary());
        pstmt.setInt(14, professor.getHoursPerWeek());
        pstmt.setDouble(15, professor.getHourlyRate());
        pstmt.setString(16, professor.getStatus());
    }

    private boolean columnExists(ResultSet rs, String columnName) {
        try {
            rs.findColumn(columnName);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    private void handleException(String operation, SQLException e) {
        System.err.println("Error during " + operation + ": " + e.getMessage());
        e.printStackTrace();
    }
}