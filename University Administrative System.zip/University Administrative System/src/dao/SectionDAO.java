package dao;

import model.Section;
import model.SectionSchedule;
import model.Student;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class SectionDAO implements DAO<Section> {
    private final Connection connection;

    public SectionDAO(Connection connection) {
        this.connection = connection;
    }

    @Override
    public Optional<Section> get(int id) {
        String sql = "SELECT s.*, sub.subject_name, sub.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM sections s " +
                "JOIN subjects sub ON s.subject_id = sub.subject_id " +
                "JOIN professors p ON s.professor_id = p.professor_id " +
                "WHERE s.section_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Section section = mapResultSetToSection(rs);
                // Cargar horarios
                section.setSchedules(getSchedulesBySection(id));
                // Cargar estudiantes inscritos
                section.setEnrolledStudents(getEnrolledStudents(id));
                return Optional.of(section);
            }
            return Optional.empty();
        } catch (SQLException e) {
            handleException("get section by ID", e);
            return Optional.empty();
        }
    }

    @Override
    public List<Section> getAll() {
        List<Section> sections = new ArrayList<>();
        String sql = "SELECT s.*, sub.subject_name, sub.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM sections s " +
                "JOIN subjects sub ON s.subject_id = sub.subject_id " +
                "JOIN professors p ON s.professor_id = p.professor_id " +
                "ORDER BY s.subject_id, s.section_code";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Section section = mapResultSetToSection(rs);
                section.setSchedules(getSchedulesBySection(section.getSectionId()));
                sections.add(section);
            }
        } catch (SQLException e) {
            handleException("get all sections", e);
        }
        return sections;
    }

    @Override
    public boolean save(Section section) {
        String sql = "INSERT INTO sections (subject_id, section_code, professor_id, capacity, current_enrollment, status) " +
                "VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql, new String[]{"section_id"})) {
            pstmt.setInt(1, section.getSubjectId());
            pstmt.setString(2, section.getSectionCode());
            pstmt.setInt(3, section.getProfessorId());
            pstmt.setInt(4, section.getCapacity());
            pstmt.setInt(5, section.getCurrentEnrollment());
            pstmt.setString(6, section.getStatus());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        section.setSectionId(generatedKeys.getInt(1));
                    }
                }
                return true;
            }
            return false;
        } catch (SQLException e) {
            handleException("save section", e);
            return false;
        }
    }

    @Override
    public boolean update(Section section) {
        String sql = "UPDATE sections SET subject_id = ?, section_code = ?, professor_id = ?, " +
                "capacity = ?, current_enrollment = ?, status = ? WHERE section_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, section.getSubjectId());
            pstmt.setString(2, section.getSectionCode());
            pstmt.setInt(3, section.getProfessorId());
            pstmt.setInt(4, section.getCapacity());
            pstmt.setInt(5, section.getCurrentEnrollment());
            pstmt.setString(6, section.getStatus());
            pstmt.setInt(7, section.getSectionId());

            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("update section", e);
            return false;
        }
    }

    @Override
    public boolean delete(Section section) {
        return deleteById(section.getSectionId());
    }

    @Override
    public boolean deleteById(int id) {
        String sql = "DELETE FROM sections WHERE section_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, id);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("delete section", e);
            return false;
        }
    }

    @Override
    public int count() {
        String sql = "SELECT COUNT(*) FROM sections WHERE status = 'ACTIVE'";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            return rs.next() ? rs.getInt(1) : 0;
        } catch (SQLException e) {
            handleException("count sections", e);
            return 0;
        }
    }

    @Override
    public boolean exists(int id) {
        return get(id).isPresent();
    }

    // Métodos específicos para secciones
    public List<Section> getBySubject(int subjectId) {
        List<Section> sections = new ArrayList<>();
        String sql = "SELECT s.*, sub.subject_name, sub.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM sections s " +
                "JOIN subjects sub ON s.subject_id = sub.subject_id " +
                "JOIN professors p ON s.professor_id = p.professor_id " +
                "WHERE s.subject_id = ? ORDER BY s.section_code";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, subjectId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Section section = mapResultSetToSection(rs);
                section.setSchedules(getSchedulesBySection(section.getSectionId()));
                sections.add(section);
            }
        } catch (SQLException e) {
            handleException("get sections by subject", e);
        }
        return sections;
    }

    public Optional<Section> getAvailableSection(int subjectId) {
        String sql = "SELECT s.*, sub.subject_name, sub.code as subject_code, " +
                "p.first_name || ' ' || p.last_name as professor_name " +
                "FROM sections s " +
                "JOIN subjects sub ON s.subject_id = sub.subject_id " +
                "JOIN professors p ON s.professor_id = p.professor_id " +
                "WHERE s.subject_id = ? AND s.status = 'ACTIVE' AND s.current_enrollment < s.capacity " +
                "ORDER BY s.section_code " +
                "FETCH FIRST 1 ROWS ONLY";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, subjectId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                Section section = mapResultSetToSection(rs);
                section.setSchedules(getSchedulesBySection(section.getSectionId()));
                return Optional.of(section);
            }
            return Optional.empty();
        } catch (SQLException e) {
            handleException("get available section", e);
            return Optional.empty();
        }
    }

    public String getNextSectionCode(int subjectId) {
        String sql = "SELECT section_code FROM sections WHERE subject_id = ? ORDER BY section_code DESC FETCH FIRST 1 ROWS ONLY";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, subjectId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                String lastCode = rs.getString("section_code");
                // Generar siguiente código (A -> B, B -> C, etc.)
                return String.valueOf((char) (lastCode.charAt(0) + 1));
            }
            // Si no hay secciones, empezar con A
            return "A";
        } catch (SQLException e) {
            handleException("get next section code", e);
            return "A";
        }
    }

    public boolean incrementEnrollment(int sectionId) {
        String sql = "UPDATE sections SET current_enrollment = current_enrollment + 1 WHERE section_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, sectionId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("increment enrollment", e);
            return false;
        }
    }

    public boolean decrementEnrollment(int sectionId) {
        String sql = "UPDATE sections SET current_enrollment = current_enrollment - 1 WHERE section_id = ? AND current_enrollment > 0";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, sectionId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("decrement enrollment", e);
            return false;
        }
    }

    // Métodos para horarios de secciones
    public boolean addSchedule(SectionSchedule schedule) {
        String sql = "INSERT INTO section_schedules (section_id, day_of_week, start_time, end_time, classroom) " +
                "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, schedule.getSectionId());
            pstmt.setString(2, schedule.getDayOfWeek());
            pstmt.setString(3, schedule.getStartTime());
            pstmt.setString(4, schedule.getEndTime());
            pstmt.setString(5, schedule.getClassroom());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            handleException("add section schedule", e);
            return false;
        }
    }

    public List<SectionSchedule> getSchedulesBySection(int sectionId) {
        List<SectionSchedule> schedules = new ArrayList<>();
        String sql = "SELECT * FROM section_schedules WHERE section_id = ? ORDER BY day_of_week, start_time";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, sectionId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                schedules.add(mapResultSetToSchedule(rs));
            }
        } catch (SQLException e) {
            handleException("get schedules by section", e);
        }
        return schedules;
    }

    // Métodos para estudiantes inscritos
    public List<Student> getEnrolledStudents(int sectionId) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT st.* FROM students st " +
                "JOIN enrollments e ON st.student_id = e.student_id " +
                "WHERE e.section_id = ? AND e.status = 'ENROLLED' " +
                "ORDER BY st.last_name, st.first_name";
        try (PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setInt(1, sectionId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                Student student = new Student();
                student.setStudentId(rs.getInt("student_id"));
                student.setFirstName(rs.getString("first_name"));
                student.setLastName(rs.getString("last_name"));
                student.setEmail(rs.getString("email"));
                student.setCareer(rs.getString("career"));
                student.setSemester(rs.getInt("semester"));
                students.add(student);
            }
        } catch (SQLException e) {
            handleException("get enrolled students", e);
        }
        return students;
    }

    // Métodos de mapeo
    private Section mapResultSetToSection(ResultSet rs) throws SQLException {
        Section section = new Section();
        section.setSectionId(rs.getInt("section_id"));
        section.setSubjectId(rs.getInt("subject_id"));
        section.setSectionCode(rs.getString("section_code"));
        section.setProfessorId(rs.getInt("professor_id"));
        section.setCapacity(rs.getInt("capacity"));
        section.setCurrentEnrollment(rs.getInt("current_enrollment"));
        section.setStatus(rs.getString("status"));
        section.setSubjectName(rs.getString("subject_name"));
        section.setSubjectCode(rs.getString("subject_code"));
        section.setProfessorName(rs.getString("professor_name"));
        return section;
    }

    private SectionSchedule mapResultSetToSchedule(ResultSet rs) throws SQLException {
        SectionSchedule schedule = new SectionSchedule();
        schedule.setScheduleId(rs.getInt("schedule_id"));
        schedule.setSectionId(rs.getInt("section_id"));
        schedule.setDayOfWeek(rs.getString("day_of_week"));
        schedule.setStartTime(rs.getString("start_time"));
        schedule.setEndTime(rs.getString("end_time"));
        schedule.setClassroom(rs.getString("classroom"));
        return schedule;
    }

    private void handleException(String operation, SQLException e) {
        System.err.println("Error during " + operation + ": " + e.getMessage());
        e.printStackTrace();
    }
}