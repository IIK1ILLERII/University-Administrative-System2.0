package model;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class ClassSchedule {
    private int scheduleId;
    private int subjectId;
    private int professorId;
    private String dayOfWeek;
    private String startTime;
    private String endTime;
    private String classroom;
    private String status;

    // Campos para mostrar en la interfaz
    private String subjectName;
    private String professorName;
    private String subjectCode;

    public ClassSchedule() {
        this.status = "ACTIVE";
    }

    public ClassSchedule(int subjectId, int professorId, String dayOfWeek,
                         String startTime, String endTime, String classroom) {
        this();
        this.subjectId = subjectId;
        this.professorId = professorId;
        this.dayOfWeek = dayOfWeek;
        this.startTime = startTime;
        this.endTime = endTime;
        this.classroom = classroom;
    }

    // Getters and Setters
    public int getScheduleId() { return scheduleId; }
    public void setScheduleId(int scheduleId) { this.scheduleId = scheduleId; }

    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }

    public int getProfessorId() { return professorId; }
    public void setProfessorId(int professorId) { this.professorId = professorId; }

    public String getDayOfWeek() { return dayOfWeek; }
    public void setDayOfWeek(String dayOfWeek) { this.dayOfWeek = dayOfWeek; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public String getClassroom() { return classroom; }
    public void setClassroom(String classroom) { this.classroom = classroom; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getProfessorName() { return professorName; }
    public void setProfessorName(String professorName) { this.professorName = professorName; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    // Métodos utilitarios
    public LocalTime getStartTimeAsLocalTime() {
        return LocalTime.parse(startTime, DateTimeFormatter.ofPattern("HH:mm"));
    }

    public LocalTime getEndTimeAsLocalTime() {
        return LocalTime.parse(endTime, DateTimeFormatter.ofPattern("HH:mm"));
    }

    public String getTimeRange() {
        return startTime + " - " + endTime;
    }

    public int getDurationInMinutes() {
        LocalTime start = getStartTimeAsLocalTime();
        LocalTime end = getEndTimeAsLocalTime();
        return (int) java.time.Duration.between(start, end).toMinutes();
    }

    public boolean overlapsWith(ClassSchedule other) {
        if (!this.dayOfWeek.equals(other.dayOfWeek)) return false;

        LocalTime thisStart = this.getStartTimeAsLocalTime();
        LocalTime thisEnd = this.getEndTimeAsLocalTime();
        LocalTime otherStart = other.getStartTimeAsLocalTime();
        LocalTime otherEnd = other.getEndTimeAsLocalTime();

        return thisStart.isBefore(otherEnd) && otherStart.isBefore(thisEnd);
    }

    @Override
    public String toString() {
        return String.format("%s %s (%s) - %s", dayOfWeek, getTimeRange(), classroom, professorName);
    }
}