package model;

import java.time.LocalDate;

public class Enrollment {
    private int enrollmentId;
    private int studentId;
    private int subjectId;
    private int professorId;
    private Integer sectionId;
    private String enrollmentDate;
    private Double grade;
    private String status;
    private String semester;
    private String enrollmentType;

    // Campos para mostrar en la interfaz
    private String studentName;
    private String subjectName;
    private String professorName;
    private String sectionCode;
    private String subjectCode;
    private String studentEmail;
    private String career;
    private Integer studentSemester;

    public Enrollment() {
        this.status = "ENROLLED";
        this.enrollmentDate = LocalDate.now().toString();
        this.enrollmentType = "REGULAR";
    }

    // Constructor para inscripción automática (sin sección específica)
    public Enrollment(int studentId, int subjectId, String semester) {
        this();
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.semester = semester;
    }

    // Constructor para inscripción con sección específica
    public Enrollment(int studentId, int subjectId, int sectionId, int professorId, String semester) {
        this();
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.sectionId = sectionId;
        this.professorId = professorId;
        this.semester = semester;
    }

    // Constructor completo
    public Enrollment(int studentId, int subjectId, int professorId, Integer sectionId,
                      String semester, String enrollmentType) {
        this();
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.professorId = professorId;
        this.sectionId = sectionId;
        this.semester = semester;
        this.enrollmentType = enrollmentType != null ? enrollmentType : "REGULAR";
    }

    // ===== GETTERS AND SETTERS =====

    public int getEnrollmentId() { return enrollmentId; }
    public void setEnrollmentId(int enrollmentId) { this.enrollmentId = enrollmentId; }

    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }

    public int getProfessorId() { return professorId; }
    public void setProfessorId(int professorId) { this.professorId = professorId; }

    public Integer getSectionId() { return sectionId; }
    public void setSectionId(Integer sectionId) { this.sectionId = sectionId; }

    public String getEnrollmentDate() { return enrollmentDate; }
    public void setEnrollmentDate(String enrollmentDate) { this.enrollmentDate = enrollmentDate; }

    public Double getGrade() { return grade; }
    public void setGrade(Double grade) { this.grade = grade; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getEnrollmentType() { return enrollmentType; }
    public void setEnrollmentType(String enrollmentType) { this.enrollmentType = enrollmentType; }

    // ===== CAMPOS DE VISUALIZACIÓN =====

    public String getStudentName() { return studentName; }
    public void setStudentName(String studentName) { this.studentName = studentName; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getProfessorName() { return professorName; }
    public void setProfessorName(String professorName) { this.professorName = professorName; }

    public String getSectionCode() { return sectionCode; }
    public void setSectionCode(String sectionCode) { this.sectionCode = sectionCode; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    public String getStudentEmail() { return studentEmail; }
    public void setStudentEmail(String studentEmail) { this.studentEmail = studentEmail; }

    public String getCareer() { return career; }
    public void setCareer(String career) { this.career = career; }

    public Integer getStudentSemester() { return studentSemester; }
    public void setStudentSemester(Integer studentSemester) { this.studentSemester = studentSemester; }

    // ===== MÉTODOS DE LÓGICA DE NEGOCIO =====

    public boolean isPassed() {
        return grade != null && grade >= 70.0 && "PASSED".equals(status);
    }

    public boolean isFailed() {
        return grade != null && grade < 70.0 && "FAILED".equals(status);
    }

    public boolean isEnrolled() {
        return "ENROLLED".equals(status);
    }

    public boolean isDropped() {
        return "DROPPED".equals(status);
    }

    public boolean hasGrade() {
        return grade != null;
    }

    public String getGradeStatus() {
        if (grade == null) return "En curso";
        return isPassed() ? "Aprobado" : "Reprobado";
    }

    public String getGradeColor() {
        if (grade == null) return "🟡";
        return isPassed() ? "🟢" : "🔴";
    }

    public String getFullSectionCode() {
        if (sectionCode != null && subjectCode != null) {
            return subjectCode + "-" + sectionCode;
        }
        return sectionCode != null ? sectionCode : "N/A";
    }

    public String getStudentInfo() {
        if (studentName != null && career != null && studentSemester != null) {
            return String.format("%s - %s (%dº semestre)", studentName, career, studentSemester);
        }
        return studentName != null ? studentName : "Estudiante " + studentId;
    }

    public String getSubjectInfo() {
        if (subjectName != null && subjectCode != null) {
            return String.format("%s - %s", subjectCode, subjectName);
        }
        return subjectName != null ? subjectName : "Materia " + subjectId;
    }

    public boolean canBeGraded() {
        return isEnrolled() && !hasGrade();
    }

    public boolean canBeDropped() {
        return isEnrolled() && !hasGrade();
    }

    public String getFormattedGrade() {
        if (grade == null) return "N/A";
        return String.format("%.2f", grade);
    }

    public String getLetterGrade() {
        if (grade == null) return "N/A";

        if (grade >= 90) return "A";
        else if (grade >= 80) return "B";
        else if (grade >= 70) return "C";
        else if (grade >= 60) return "D";
        else return "F";
    }

    public double getQualityPoints() {
        if (grade == null) return 0.0;

        if (grade >= 90) return 4.0;
        else if (grade >= 80) return 3.0;
        else if (grade >= 70) return 2.0;
        else if (grade >= 60) return 1.0;
        else return 0.0;
    }

    // ===== MÉTODOS DE VALIDACIÓN =====

    public boolean isValid() {
        return studentId > 0 &&
                subjectId > 0 &&
                semester != null &&
                !semester.trim().isEmpty() &&
                status != null;
    }

    public boolean isGradeValid() {
        return grade == null || (grade >= 0 && grade <= 100);
    }

    // ===== MÉTODOS DE REPRESENTACIÓN =====

    @Override
    public String toString() {
        return String.format("Inscripción #%d: %s en %s - %s",
                enrollmentId,
                studentName != null ? studentName : "Estudiante " + studentId,
                subjectName != null ? subjectName : "Materia " + subjectId,
                status);
    }

    public String toDetailedString() {
        return String.format(
                "Enrollment ID: %d\n" +
                        "Estudiante: %s (%s)\n" +
                        "Materia: %s\n" +
                        "Sección: %s\n" +
                        "Profesor: %s\n" +
                        "Semestre: %s\n" +
                        "Fecha: %s\n" +
                        "Calificación: %s\n" +
                        "Estado: %s\n" +
                        "Tipo: %s",
                enrollmentId,
                getStudentInfo(),
                studentEmail != null ? studentEmail : "N/A",
                getSubjectInfo(),
                getFullSectionCode(),
                professorName != null ? professorName : "Profesor " + professorId,
                semester,
                enrollmentDate,
                getFormattedGrade(),
                status,
                enrollmentType
        );
    }

    public String toShortString() {
        return String.format("%s - %s (%s)",
                studentName != null ? studentName : "Est " + studentId,
                subjectName != null ? subjectName : "Mat " + subjectId,
                semester);
    }
}