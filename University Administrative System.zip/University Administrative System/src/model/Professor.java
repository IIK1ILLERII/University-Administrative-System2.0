package model;

public class Professor {
    private int professorId;
    private String firstName;
    private String paternalLastName;
    private String maternalLastName;
    private String email;
    private String phone;
    private String dni;
    private String gender;
    private int age;
    private String district;
    private String department;
    private String specialty;
    private String professorType;
    private double fixedSalary;
    private int hoursPerWeek;
    private double hourlyRate;
    private String status;

    public Professor() {
        this.status = "ACTIVE";
        this.professorType = "TIEMPO_COMPLETO";
    }

    public Professor(String firstName, String paternalLastName, String maternalLastName,
                     String email, String department, String specialty) {
        this();
        this.firstName = firstName;
        this.paternalLastName = paternalLastName;
        this.maternalLastName = maternalLastName;
        this.email = email;
        this.department = department;
        this.specialty = specialty;
    }

    // Getters and Setters
    public int getProfessorId() { return professorId; }
    public void setProfessorId(int professorId) { this.professorId = professorId; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getPaternalLastName() { return paternalLastName; }
    public void setPaternalLastName(String paternalLastName) { this.paternalLastName = paternalLastName; }

    public String getMaternalLastName() { return maternalLastName; }
    public void setMaternalLastName(String maternalLastName) { this.maternalLastName = maternalLastName; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getSpecialty() { return specialty; }
    public void setSpecialty(String specialty) { this.specialty = specialty; }

    public String getProfessorType() { return professorType; }
    public void setProfessorType(String professorType) { this.professorType = professorType; }

    public double getFixedSalary() { return fixedSalary; }
    public void setFixedSalary(double fixedSalary) { this.fixedSalary = fixedSalary; }

    public int getHoursPerWeek() { return hoursPerWeek; }
    public void setHoursPerWeek(int hoursPerWeek) { this.hoursPerWeek = hoursPerWeek; }

    public double getHourlyRate() { return hourlyRate; }
    public void setHourlyRate(double hourlyRate) { this.hourlyRate = hourlyRate; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    // Método de compatibilidad (para no romper código existente)
    public String getLastName() {
        return paternalLastName + " " + maternalLastName;
    }

    public double getSalary() {
        if ("TIEMPO_COMPLETO".equals(professorType)) {
            return fixedSalary;
        } else {
            return hoursPerWeek * hourlyRate * 4; // Salario mensual estimado
        }
    }

    public String getFullName() {
        return firstName + " " + paternalLastName + " " + maternalLastName;
    }

    public boolean isActive() {
        return "ACTIVE".equals(status);
    }

    @Override
    public String toString() {
        return String.format("%s %s %s - %s", firstName, paternalLastName, maternalLastName, department);
    }

    public String toDetailedString() {
        if ("TIEMPO_COMPLETO".equals(professorType)) {
            return String.format(
                    "Profesor ID: %d\nNombre: %s %s %s\nDNI: %s\nEmail: %s\nDepartamento: %s\nEspecialidad: %s\nTipo: %s\nSalario Fijo: S/.%.2f\nEstado: %s",
                    professorId, firstName, paternalLastName, maternalLastName, dni, email,
                    department, specialty, professorType, fixedSalary, status
            );
        } else {
            double monthlySalary = hoursPerWeek * hourlyRate * 4;
            return String.format(
                    "Profesor ID: %d\nNombre: %s %s %s\nDNI: %s\nEmail: %s\nDepartamento: %s\nEspecialidad: %s\nTipo: %s\nHoras/Semana: %d\nTarifa/Hora: S/.%.2f\nSalario Estimado: S/.%.2f\nEstado: %s",
                    professorId, firstName, paternalLastName, maternalLastName, dni, email,
                    department, specialty, professorType, hoursPerWeek, hourlyRate, monthlySalary, status
            );
        }
    }
}