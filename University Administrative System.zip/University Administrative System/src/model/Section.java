package model;

import java.util.ArrayList;
import java.util.List;

public class Section {
    private int sectionId;
    private int subjectId;
    private String sectionCode;
    private int professorId;
    private int capacity;
    private int currentEnrollment;
    private String status;

    // Campos para mostrar en la interfaz
    private String subjectName;
    private String subjectCode;
    private String professorName;
    private List<SectionSchedule> schedules;
    private List<Student> enrolledStudents;

    public Section() {
        this.capacity = 30;
        this.currentEnrollment = 0;
        this.status = "ACTIVE";
        this.schedules = new ArrayList<>();
        this.enrolledStudents = new ArrayList<>();
    }

    public Section(int subjectId, String sectionCode, int professorId) {
        this();
        this.subjectId = subjectId;
        this.sectionCode = sectionCode;
        this.professorId = professorId;
    }

    // Getters and Setters
    public int getSectionId() { return sectionId; }
    public void setSectionId(int sectionId) { this.sectionId = sectionId; }

    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }

    public String getSectionCode() { return sectionCode; }
    public void setSectionCode(String sectionCode) { this.sectionCode = sectionCode; }

    public int getProfessorId() { return professorId; }
    public void setProfessorId(int professorId) { this.professorId = professorId; }

    public int getCapacity() { return capacity; }
    public void setCapacity(int capacity) { this.capacity = capacity; }

    public int getCurrentEnrollment() { return currentEnrollment; }
    public void setCurrentEnrollment(int currentEnrollment) { this.currentEnrollment = currentEnrollment; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getSubjectCode() { return subjectCode; }
    public void setSubjectCode(String subjectCode) { this.subjectCode = subjectCode; }

    public String getProfessorName() { return professorName; }
    public void setProfessorName(String professorName) { this.professorName = professorName; }

    public List<SectionSchedule> getSchedules() { return schedules; }
    public void setSchedules(List<SectionSchedule> schedules) { this.schedules = schedules; }
    public void addSchedule(SectionSchedule schedule) { this.schedules.add(schedule); }

    public List<Student> getEnrolledStudents() { return enrolledStudents; }
    public void setEnrolledStudents(List<Student> enrolledStudents) { this.enrolledStudents = enrolledStudents; }
    public void addEnrolledStudent(Student student) { this.enrolledStudents.add(student); }

    // Métodos utilitarios
    public boolean isFull() {
        return currentEnrollment >= capacity;
    }

    public int getAvailableSpots() {
        return capacity - currentEnrollment;
    }

    public boolean canEnroll() {
        return "ACTIVE".equals(status) && !isFull();
    }

    public String getFullSectionCode() {
        return subjectCode + "-" + sectionCode;
    }

    public String getScheduleSummary() {
        if (schedules.isEmpty()) {
            return "Sin horario asignado";
        }
        StringBuilder summary = new StringBuilder();
        for (SectionSchedule schedule : schedules) {
            summary.append(schedule.getDayOfWeek()).append(" ")
                    .append(schedule.getTimeRange()).append(", ");
        }
        return summary.length() > 0 ? summary.substring(0, summary.length() - 2) : "";
    }

    @Override
    public String toString() {
        return String.format("%s-%s (%d/%d)", subjectCode, sectionCode, currentEnrollment, capacity);
    }
}