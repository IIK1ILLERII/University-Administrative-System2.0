package model;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Student {
    private int studentId;
    private String dni;
    private String firstName;
    private String lastName1;  // Apellido paterno
    private String lastName2;  // Apellido materno
    private int age;
    private String gender;     // M o F
    private String email;
    private String phone;
    private String address;
    private String district;
    private String career;
    private int semester;
    private String enrollmentDate;
    private String dateOfBirth;
    private String status;
    private double gpa;

    public Student() {
        this.status = "ACTIVE";
        this.gpa = 0.0;
        this.enrollmentDate = LocalDate.now().toString();
        this.gender = "M"; // Valor por defecto
    }

    // Constructor actualizado
    public Student(String dni, String firstName, String lastName1, String lastName2,
                   String email, String career, int semester) {
        this();
        this.dni = dni;
        this.firstName = firstName;
        this.lastName1 = lastName1;
        this.lastName2 = lastName2;
        this.email = email;
        this.career = career;
        this.semester = semester;
    }

    // Constructor completo
    public Student(String dni, String firstName, String lastName1, String lastName2,
                   int age, String gender, String email, String phone, String address,
                   String district, String career, int semester, String dateOfBirth) {
        this();
        this.dni = dni;
        this.firstName = firstName;
        this.lastName1 = lastName1;
        this.lastName2 = lastName2;
        this.age = age;
        this.gender = gender;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.district = district;
        this.career = career;
        this.semester = semester;
        this.dateOfBirth = dateOfBirth;
    }

    // Getters and Setters
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }

    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName1() { return lastName1; }
    public void setLastName1(String lastName1) { this.lastName1 = lastName1; }

    public String getLastName2() { return lastName2; }
    public void setLastName2(String lastName2) { this.lastName2 = lastName2; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getDistrict() { return district; }
    public void setDistrict(String district) { this.district = district; }

    public String getCareer() { return career; }
    public void setCareer(String career) { this.career = career; }

    public int getSemester() { return semester; }
    public void setSemester(int semester) { this.semester = semester; }

    public String getEnrollmentDate() { return enrollmentDate; }
    public void setEnrollmentDate(String enrollmentDate) { this.enrollmentDate = enrollmentDate; }

    public String getDateOfBirth() { return dateOfBirth; }
    public void setDateOfBirth(String dateOfBirth) { this.dateOfBirth = dateOfBirth; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public double getGpa() { return gpa; }
    public void setGpa(double gpa) { this.gpa = gpa; }

    // Métodos de compatibilidad (para mantener funcionalidad existente)
    public String getLastName() {
        return lastName1; // Retorna el apellido paterno por compatibilidad
    }

    public void setLastName(String lastName) {
        this.lastName1 = lastName; // Asigna al apellido paterno por compatibilidad
    }

    // Métodos utilitarios
    public String getFullName() {
        return firstName + " " + lastName1 + " " + (lastName2 != null ? lastName2 : "");
    }

    public String getFullNameWithLastNames() {
        return lastName1 + " " + lastName2 + ", " + firstName;
    }

    public boolean isActive() {
        return "ACTIVE".equals(status);
    }

    public String getGenderDisplay() {
        return "M".equals(gender) ? "Masculino" : "F".equals(gender) ? "Femenino" : "No especificado";
    }

    public String getStatusDisplay() {
        switch (status) {
            case "ACTIVE": return "Activo";
            case "INACTIVE": return "Inactivo";
            case "GRADUATED": return "Graduado";
            default: return status;
        }
    }

    // Método para calcular edad a partir de la fecha de nacimiento
    public int calculateAge() {
        if (dateOfBirth == null || dateOfBirth.isEmpty()) {
            return age; // Retorna la edad establecida si no hay fecha de nacimiento
        }

        try {
            LocalDate birthDate = LocalDate.parse(dateOfBirth);
            LocalDate currentDate = LocalDate.now();
            return currentDate.getYear() - birthDate.getYear() -
                    (currentDate.getDayOfYear() < birthDate.getDayOfYear() ? 1 : 0);
        } catch (Exception e) {
            return age; // Retorna la edad establecida si hay error en el parsing
        }
    }

    // Validaciones
    public boolean isValidDni() {
        return dni != null && dni.matches("\\d{8}"); // 8 dígitos para DNI peruano
    }

    public boolean isValidEmail() {
        return email != null && email.matches("^[A-Za-z0-9+_.-]+@(.+)$");
    }

    public boolean isAdult() {
        return age >= 18;
    }

    @Override
    public String toString() {
        return String.format("%s %s %s - %s (Semestre %d)",
                firstName, lastName1, lastName2 != null ? lastName2 : "", career, semester);
    }

    public String toDetailedString() {
        return String.format(
                "Estudiante ID: %d\n" +
                        "DNI: %s\n" +
                        "Nombre: %s %s %s\n" +
                        "Edad: %d años\n" +
                        "Sexo: %s\n" +
                        "Email: %s\n" +
                        "Teléfono: %s\n" +
                        "Dirección: %s\n" +
                        "Distrito: %s\n" +
                        "Carrera: %s\n" +
                        "Semestre: %d\n" +
                        "GPA: %.2f\n" +
                        "Fecha Nacimiento: %s\n" +
                        "Fecha Inscripción: %s\n" +
                        "Estado: %s",
                studentId, dni, firstName, lastName1,
                lastName2 != null ? lastName2 : "", age, getGenderDisplay(),
                email, phone != null ? phone : "No registrado",
                address != null ? address : "No registrada",
                district != null ? district : "No registrado",
                career, semester, gpa,
                dateOfBirth != null ? dateOfBirth : "No registrada",
                enrollmentDate, getStatusDisplay()
        );
    }

    // Método para información resumida en tabla
    public String toTableString() {
        return String.format("%s %s %s | %s | Sem %d",
                firstName, lastName1, lastName2 != null ? lastName2 : "", career, semester);
    }

    // equals y hashCode basados en DNI (único por estudiante)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Student student = (Student) o;
        return dni != null ? dni.equals(student.dni) : student.dni == null;
    }

    @Override
    public int hashCode() {
        return dni != null ? dni.hashCode() : 0;
    }
}