package model;

import java.util.ArrayList;
import java.util.List;

public class Subject {
    private int subjectId;
    private String subjectName;
    private String code;
    private int credits;
    private int professorId;
    private String professorName;
    private String department;
    private String difficultyLevel;
    private int hoursPerWeek;
    private String status;

    // Nuevos campos para horarios
    private String startTime;
    private String endTime;
    private List<ClassSchedule> schedules;

    public Subject() {
        this.difficultyLevel = "BASIC";
        this.credits = 3;
        this.hoursPerWeek = 4;
        this.status = "ACTIVE";
        this.schedules = new ArrayList<>();
    }

    public Subject(String subjectName, String code, int credits, String department) {
        this();
        this.subjectName = subjectName;
        this.code = code;
        this.credits = credits;
        this.department = department;
    }

    public boolean isActive() {
        return "ACTIVE".equals(status);
    }

    // Getters and Setters (mantener los existentes y agregar nuevos)
    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }

    public String getSubjectName() { return subjectName; }
    public void setSubjectName(String subjectName) { this.subjectName = subjectName; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public int getCredits() { return credits; }
    public void setCredits(int credits) { this.credits = credits; }

    public int getProfessorId() { return professorId; }
    public void setProfessorId(int professorId) { this.professorId = professorId; }

    public String getProfessorName() { return professorName; }
    public void setProfessorName(String professorName) { this.professorName = professorName; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getDifficultyLevel() { return difficultyLevel; }
    public void setDifficultyLevel(String difficultyLevel) { this.difficultyLevel = difficultyLevel; }

    public int getHoursPerWeek() { return hoursPerWeek; }
    public void setHoursPerWeek(int hoursPerWeek) { this.hoursPerWeek = hoursPerWeek; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getStartTime() { return startTime; }
    public void setStartTime(String startTime) { this.startTime = startTime; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }

    public List<ClassSchedule> getSchedules() { return schedules; }
    public void setSchedules(List<ClassSchedule> schedules) { this.schedules = schedules; }
    public void addSchedule(ClassSchedule schedule) { this.schedules.add(schedule); }

    public String getDifficultyColor() {
        switch (difficultyLevel.toUpperCase()) {
            case "BASIC": return "🟢";
            case "INTERMEDIATE": return "🟡";
            case "ADVANCED": return "🔴";
            default: return "⚪";
        }
    }

    public String getScheduleSummary() {
        if (schedules.isEmpty()) {
            return "Sin horario asignado";
        }
        StringBuilder summary = new StringBuilder();
        for (ClassSchedule schedule : schedules) {
            summary.append(schedule.getDayOfWeek()).append(" ")
                    .append(schedule.getTimeRange()).append(", ");
        }
        return summary.length() > 0 ? summary.substring(0, summary.length() - 2) : "";
    }

    @Override
    public String toString() {
        return String.format("%s - %s (%d créditos)", code, subjectName, credits);
    }

    public String toDetailedString() {
        return String.format(
                "Materia ID: %d\nCódigo: %s\nNombre: %s\nCréditos: %d\nDepartamento: %s\nDificultad: %s\nHoras/Semana: %d\nProfesor: %s\nHorarios: %s",
                subjectId, code, subjectName, credits, department, difficultyLevel, hoursPerWeek,
                professorName != null ? professorName : "No asignado",
                getScheduleSummary()
        );
    }
}