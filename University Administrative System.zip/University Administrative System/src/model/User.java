package model;

public class User {
    private String username;
    private String password;
    private UserType type;

    public enum UserType {
        ADMINISTRADOR("Administrador"),
        MATRICULADOR("Matriculador"),
        CONTRATADOR("Contratador"),
        INSCRIPTOR("Inscriptor");

        private final String displayName;

        UserType(String displayName) {
            this.displayName = displayName;
        }

        public String getDisplayName() {
            return displayName;
        }

        @Override
        public String toString() {
            return displayName;
        }
    }

    public User(String username, String password, UserType type) {
        this.username = username;
        this.password = password;
        this.type = type;
    }

    // Getters
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public UserType getType() { return type; }

    // Verificar credenciales
    public boolean verificarCredenciales(String username, String password) {
        return this.username.equals(username) && this.password.equals(password);
    }
}