package service;

import model.User;
import java.util.ArrayList;
import java.util.List;

public class AuthService {
    private List<User> users;
    private User currentUser;

    public AuthService() {
        inicializarUsuarios();
    }

    private void inicializarUsuarios() {
        users = new ArrayList<>();

        // Usuarios predefinidos - puedes cambiar las contraseñas
        users.add(new User("admin", "admin123", User.UserType.ADMINISTRADOR));
        users.add(new User("matricula", "mat123", User.UserType.MATRICULADOR));
        users.add(new User("contrata", "cont123", User.UserType.CONTRATADOR));
        users.add(new User("inscribe", "ins123", User.UserType.INSCRIPTOR));
    }

    public boolean autenticar(String username, String password) {
        for (User user : users) {
            if (user.verificarCredenciales(username, password)) {
                currentUser = user;
                return true;
            }
        }
        return false;
    }

    public User getCurrentUser() {
        return currentUser;
    }

    public void logout() {
        currentUser = null;
    }

    public boolean isLoggedIn() {
        return currentUser != null;
    }

    // Método para agregar usuarios dinámicamente (opcional)
    public void agregarUsuario(User user) {
        users.add(user);
    }
}