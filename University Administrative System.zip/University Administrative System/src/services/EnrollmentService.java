package services;

import dao.EnrollmentDAO;
import dao.SectionDAO;
import model.Enrollment;
import model.Section;
import model.DatabaseConnection;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public class EnrollmentService {
    private final EnrollmentDAO enrollmentDAO;
    private final SectionDAO sectionDAO;

    public EnrollmentService() {
        Connection conn = DatabaseConnection.getConnection();
        this.enrollmentDAO = new EnrollmentDAO(conn);
        this.sectionDAO = new SectionDAO(conn);
    }

    // ===== MÉTODOS PRINCIPALES DE INSCRIPCIÓN =====

    /**
     * Inscribe un estudiante usando el sistema automático de secciones
     */
    public boolean enrollStudent(int studentId, int subjectId, String semester) {
        if (!validateEnrollmentData(studentId, subjectId, semester)) {
            return false;
        }

        // Verificar si ya está inscrito en esta materia para el semestre
        if (isAlreadyEnrolled(studentId, subjectId, semester)) {
            showError("El estudiante ya está inscrito en esta materia para el semestre " + semester);
            return false;
        }

        // Usar el sistema automático de secciones
        Optional<Section> sectionOpt = findOrCreateSection(subjectId);
        if (sectionOpt.isEmpty()) {
            showError("No se pudo encontrar o crear una sección para esta materia");
            return false;
        }

        Section section = sectionOpt.get();
        return createEnrollment(studentId, subjectId, section, semester);
    }

    /**
     * Inscribe un estudiante en una sección específica
     */
    public boolean enrollStudentInSpecificSection(int studentId, int sectionId, String semester) {
        if (!validateEnrollmentData(studentId, 0, semester)) { // subjectId no es necesario aquí
            return false;
        }

        Optional<Section> sectionOpt = sectionDAO.get(sectionId);
        if (sectionOpt.isEmpty()) {
            showError("La sección especificada no existe");
            return false;
        }

        Section section = sectionOpt.get();

        // Verificar disponibilidad de la sección
        if (!section.canEnroll()) {
            showError("La sección está llena o no está activa");
            return false;
        }

        // Verificar si ya está inscrito en esta materia para el semestre
        if (isAlreadyEnrolled(studentId, section.getSubjectId(), semester)) {
            showError("El estudiante ya está inscrito en esta materia para el semestre " + semester);
            return false;
        }

        // Incrementar contador de la sección
        if (!sectionDAO.incrementEnrollment(sectionId)) {
            showError("Error al actualizar el contador de la sección");
            return false;
        }

        return createEnrollment(studentId, section.getSubjectId(), section, semester);
    }

    /**
     * Método para inscribir estudiante con profesor específico
     */
    public boolean enrollStudent(int studentId, int subjectId, int professorId, String semester) {
        if (!validateEnrollmentData(studentId, subjectId, semester)) {
            return false;
        }

        // Verificar si ya está inscrito en esta materia para el semestre
        if (isAlreadyEnrolled(studentId, subjectId, semester)) {
            showError("El estudiante ya está inscrito en esta materia para el semestre " + semester);
            return false;
        }

        // Crear inscripción directa con profesor específico
        Enrollment enrollment = new Enrollment();
        enrollment.setStudentId(studentId);
        enrollment.setSubjectId(subjectId);
        enrollment.setProfessorId(professorId);
        enrollment.setSemester(semester);
        enrollment.setStatus("ENROLLED");

        boolean success = enrollmentDAO.save(enrollment);
        if (success) {
            showSuccess("Estudiante inscrito exitosamente con profesor específico");
        } else {
            showError("Error al inscribir al estudiante");
        }
        return success;
    }

    // ===== MÉTODOS DE GESTIÓN DE CALIFICACIONES Y ESTADOS =====

    /**
     * Actualiza la calificación de una inscripción
     */
    public boolean updateGrade(int enrollmentId, double grade) {
        if (!validateGrade(grade)) {
            return false;
        }

        boolean success = enrollmentDAO.updateGrade(enrollmentId, grade);
        if (success) {
            // Actualizar estado automáticamente basado en la calificación
            String status = (grade >= 60) ? "PASSED" : "FAILED";
            enrollmentDAO.updateStatus(enrollmentId, status);
            showSuccess("Calificación actualizada exitosamente");
        } else {
            showError("Error al actualizar la calificación");
        }
        return success;
    }

    /**
     * Actualiza el estado de una inscripción
     */
    public boolean updateStatus(int enrollmentId, String status) {
        if (status == null || status.trim().isEmpty()) {
            showError("El estado no puede estar vacío");
            return false;
        }

        boolean success = enrollmentDAO.updateStatus(enrollmentId, status);
        if (success) {
            showSuccess("Estado actualizado exitosamente a: " + status);
        } else {
            showError("Error al actualizar el estado");
        }
        return success;
    }

    /**
     * Da de baja una inscripción (cambia estado a DROPPED)
     */
    public boolean dropEnrollment(int enrollmentId) {
        if (!confirmAction("¿Está seguro de dar de baja esta inscripción?")) {
            return false;
        }

        // Obtener la inscripción para actualizar la sección
        Optional<Enrollment> enrollmentOpt = enrollmentDAO.get(enrollmentId);
        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            // Decrementar contador de la sección si existe
            if (enrollment.getSectionId() > 0) {
                sectionDAO.decrementEnrollment(enrollment.getSectionId());
            }
        }

        boolean success = enrollmentDAO.updateStatus(enrollmentId, "DROPPED");
        if (success) {
            showSuccess("Inscripción dada de baja exitosamente");
        } else {
            showError("Error al dar de baja la inscripción");
        }
        return success;
    }

    /**
     * Elimina permanentemente una inscripción
     */
    public boolean deleteEnrollment(int enrollmentId) {
        if (!confirmAction("¿Está seguro de eliminar permanentemente esta inscripción?")) {
            return false;
        }

        // Obtener la inscripción para actualizar la sección
        Optional<Enrollment> enrollmentOpt = enrollmentDAO.get(enrollmentId);
        if (enrollmentOpt.isPresent()) {
            Enrollment enrollment = enrollmentOpt.get();
            // Decrementar contador de la sección si existe
            if (enrollment.getSectionId() > 0) {
                sectionDAO.decrementEnrollment(enrollment.getSectionId());
            }
        }

        boolean success = enrollmentDAO.deleteById(enrollmentId);
        if (success) {
            showSuccess("Inscripción eliminada exitosamente");
        } else {
            showError("Error al eliminar la inscripción");
        }
        return success;
    }

    // ===== MÉTODOS DE CONSULTA =====

    public List<Enrollment> getAllEnrollments() {
        return enrollmentDAO.getAll();
    }

    public Optional<Enrollment> getEnrollmentById(int id) {
        return enrollmentDAO.get(id);
    }

    public List<Enrollment> getEnrollmentsByStudent(int studentId) {
        return enrollmentDAO.getByStudent(studentId);
    }

    public List<Enrollment> getEnrollmentsBySubject(int subjectId) {
        return enrollmentDAO.getBySubject(subjectId);
    }

    public List<Enrollment> getEnrollmentsByProfessor(int professorId) {
        return enrollmentDAO.getByProfessor(professorId);
    }

    public List<Enrollment> getEnrollmentsBySemester(String semester) {
        return enrollmentDAO.getBySemester(semester);
    }

    public List<Enrollment> getEnrollmentsBySection(int sectionId) {
        return enrollmentDAO.getBySection(sectionId);
    }

    public List<Enrollment> getActiveEnrollments() {
        return enrollmentDAO.getByStatus("ENROLLED");
    }

    public List<Enrollment> getPassedEnrollments() {
        return enrollmentDAO.getByStatus("PASSED");
    }

    public List<Enrollment> getFailedEnrollments() {
        return enrollmentDAO.getByStatus("FAILED");
    }

    public List<Enrollment> getDroppedEnrollments() {
        return enrollmentDAO.getByStatus("DROPPED");
    }

    // ===== MÉTODOS DE CONTEO Y ESTADÍSTICAS =====

    public int countEnrollments() {
        return enrollmentDAO.count();
    }

    public int countActiveEnrollments() {
        return getActiveEnrollments().size();
    }

    public int countEnrollmentsByStudent(int studentId) {
        return getEnrollmentsByStudent(studentId).size();
    }

    public int countEnrollmentsBySubject(int subjectId) {
        return getEnrollmentsBySubject(subjectId).size();
    }

    public int countEnrollmentsBySemester(String semester) {
        return getEnrollmentsBySemester(semester).size();
    }

    public int countEnrollmentsBySection(int sectionId) {
        return getEnrollmentsBySection(sectionId).size();
    }

    public double getAverageGradeBySubject(int subjectId) {
        return enrollmentDAO.getAverageGradeBySubject(subjectId);
    }

    public int getEnrollmentCountBySubject(int subjectId) {
        return enrollmentDAO.getEnrollmentCountBySubject(subjectId);
    }

    /**
     * Calcula el GPA de un estudiante
     */
    public double getStudentGPA(int studentId) {
        List<Enrollment> enrollments = getEnrollmentsByStudent(studentId);
        List<Enrollment> gradedEnrollments = enrollments.stream()
                .filter(e -> e.getGrade() != null && e.isPassed())
                .toList();

        if (gradedEnrollments.isEmpty()) {
            return 0.0;
        }

        double total = gradedEnrollments.stream()
                .mapToDouble(Enrollment::getGrade)
                .sum();

        return total / gradedEnrollments.size();
    }

    /**
     * Obtiene todos los semestres únicos
     */
    public List<String> getAllSemesters() {
        List<Enrollment> enrollments = getAllEnrollments();
        return enrollments.stream()
                .map(Enrollment::getSemester)
                .distinct()
                .sorted()
                .toList();
    }

    /**
     * Obtiene el progreso académico de un estudiante
     */
    public String getStudentProgress(int studentId) {
        List<Enrollment> enrollments = getEnrollmentsByStudent(studentId);
        long total = enrollments.size();
        long passed = enrollments.stream().filter(Enrollment::isPassed).count();
        long enrolled = enrollments.stream().filter(Enrollment::isEnrolled).count();
        long failed = enrollments.stream().filter(Enrollment::isFailed).count();
        double gpa = getStudentGPA(studentId);

        return String.format(
                "Total: %d | Aprobadas: %d | En curso: %d | Reprobadas: %d | GPA: %.2f",
                total, passed, enrolled, failed, gpa
        );
    }

    // ===== MÉTODOS PRIVADOS AUXILIARES =====

    /**
     * Encuentra o crea una sección para una materia
     */
    private Optional<Section> findOrCreateSection(int subjectId) {
        // Buscar sección disponible
        Optional<Section> availableSection = sectionDAO.getAvailableSection(subjectId);
        if (availableSection.isPresent()) {
            Section section = availableSection.get();
            // Incrementar contador
            if (sectionDAO.incrementEnrollment(section.getSectionId())) {
                section.setCurrentEnrollment(section.getCurrentEnrollment() + 1);
                return Optional.of(section);
            }
        }

        // Crear nueva sección
        return createNewSection(subjectId);
    }

    /**
     * Crea una nueva sección para una materia
     */
    private Optional<Section> createNewSection(int subjectId) {
        String nextSectionCode = sectionDAO.getNextSectionCode(subjectId);

        // En una implementación real, necesitarías obtener el profesor de la materia
        // Por ahora usamos un valor por defecto
        int defaultProfessorId = 1;

        Section newSection = new Section();
        newSection.setSubjectId(subjectId);
        newSection.setSectionCode(nextSectionCode);
        newSection.setProfessorId(defaultProfessorId);
        newSection.setCurrentEnrollment(1);

        if (sectionDAO.save(newSection)) {
            return Optional.of(newSection);
        }

        return Optional.empty();
    }

    /**
     * Crea la inscripción en la base de datos
     */
    private boolean createEnrollment(int studentId, int subjectId, Section section, String semester) {
        Enrollment enrollment = new Enrollment();
        enrollment.setStudentId(studentId);
        enrollment.setSubjectId(subjectId);
        enrollment.setSectionId(section.getSectionId());
        enrollment.setProfessorId(section.getProfessorId());
        enrollment.setSemester(semester);
        enrollment.setStatus("ENROLLED");

        boolean success = enrollmentDAO.save(enrollment);
        if (success) {
            showSuccess("Estudiante inscrito exitosamente en la sección " + section.getSectionCode());
        } else {
            showError("Error al inscribir al estudiante");
            // Revertir el incremento de la sección si falla la inscripción
            sectionDAO.decrementEnrollment(section.getSectionId());
        }
        return success;
    }

    /**
     * Verifica si el estudiante ya está inscrito
     */
    private boolean isAlreadyEnrolled(int studentId, int subjectId, String semester) {
        List<Enrollment> existingEnrollments = enrollmentDAO.getByStudent(studentId);
        return existingEnrollments.stream()
                .anyMatch(e -> e.getSubjectId() == subjectId &&
                        e.getSemester().equals(semester) &&
                        !"DROPPED".equals(e.getStatus()));
    }

    // ===== VALIDACIONES =====

    private boolean validateEnrollmentData(int studentId, int subjectId, String semester) {
        if (studentId <= 0) {
            showError("ID de estudiante inválido");
            return false;
        }

        if (subjectId <= 0) {
            showError("ID de materia inválido");
            return false;
        }

        if (semester == null || semester.trim().isEmpty()) {
            showError("El semestre es obligatorio");
            return false;
        }

        if (!semester.matches("\\d{4}-(0[1-9]|1[0-2])")) {
            showError("Formato de semestre inválido. Use: YYYY-MM");
            return false;
        }

        return true;
    }

    private boolean validateGrade(double grade) {
        if (grade < 0 || grade > 100) {
            showError("La calificación debe estar entre 0 y 100");
            return false;
        }
        return true;
    }

    private boolean confirmAction(String message) {
        int confirm = JOptionPane.showConfirmDialog(null,
                message + "\nEsta acción no se puede deshacer.",
                "Confirmar Acción",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);
        return confirm == JOptionPane.YES_OPTION;
    }

    // ===== MÉTODOS DE MENSAJES =====

    private void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(null, message, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}