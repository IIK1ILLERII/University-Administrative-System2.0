package services;

import dao.SectionDAO;
import dao.SubjectDAO;
import dao.ProfessorDAO;
import model.Section;
import model.SectionSchedule;
import model.Subject;
import model.Professor;
import model.DatabaseConnection;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.List;
import java.util.Optional;

public class SectionService {
    private final SectionDAO sectionDAO;
    private final SubjectDAO subjectDAO;
    private final ProfessorDAO professorDAO;

    public SectionService() {
        Connection conn = DatabaseConnection.getConnection();
        this.sectionDAO = new SectionDAO(conn);
        this.subjectDAO = new SubjectDAO(conn);
        this.professorDAO = new ProfessorDAO(conn);
    }

    public Optional<Section> enrollStudentInSubject(int studentId, int subjectId) {
        try {
            // Buscar una sección disponible
            Optional<Section> availableSection = sectionDAO.getAvailableSection(subjectId);

            if (availableSection.isPresent()) {
                // Sección disponible encontrada
                Section section = availableSection.get();
                if (sectionDAO.incrementEnrollment(section.getSectionId())) {
                    section.setCurrentEnrollment(section.getCurrentEnrollment() + 1);
                    return Optional.of(section);
                }
            } else {
                // Crear nueva sección
                Optional<Subject> subjectOpt = subjectDAO.get(subjectId);
                if (subjectOpt.isPresent()) {
                    Subject subject = subjectOpt.get();
                    String nextSectionCode = sectionDAO.getNextSectionCode(subjectId);

                    // Crear nueva sección
                    Section newSection = new Section();
                    newSection.setSubjectId(subjectId);
                    newSection.setSectionCode(nextSectionCode);
                    newSection.setProfessorId(subject.getProfessorId()); // Usar el profesor de la materia
                    newSection.setCurrentEnrollment(1); // Primer estudiante

                    if (sectionDAO.save(newSection)) {
                        // Copiar horarios de la materia a la sección (si existen)
                        copySchedulesFromSubjectToSection(subjectId, newSection.getSectionId());
                        return Optional.of(newSection);
                    }
                }
            }
        } catch (Exception e) {
            showError("Error al inscribir estudiante: " + e.getMessage());
        }
        return Optional.empty();
    }

    private void copySchedulesFromSubjectToSection(int subjectId, int sectionId) {
        // Aquí podrías copiar los horarios de la materia a la sección
        // Por ahora lo dejamos vacío para que se asignen manualmente
    }

    public boolean createSection(Section section) {
        if (!validateSection(section)) {
            return false;
        }

        // Verificar que no exista ya la sección
        List<Section> existingSections = sectionDAO.getBySubject(section.getSubjectId());
        for (Section existing : existingSections) {
            if (existing.getSectionCode().equals(section.getSectionCode())) {
                showError("Ya existe una sección " + section.getSectionCode() + " para esta materia");
                return false;
            }
        }

        boolean success = sectionDAO.save(section);
        if (success) {
            showSuccess("Sección creada exitosamente");
        } else {
            showError("Error al crear la sección");
        }
        return success;
    }

    public boolean updateSection(Section section) {
        if (!validateSection(section)) {
            return false;
        }

        boolean success = sectionDAO.update(section);
        if (success) {
            showSuccess("Sección actualizada exitosamente");
        } else {
            showError("Error al actualizar la sección");
        }
        return success;
    }

    public boolean deleteSection(int sectionId) {
        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de eliminar esta sección?\nSe eliminarán todas las inscripciones asociadas.",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = sectionDAO.deleteById(sectionId);
            if (success) {
                showSuccess("Sección eliminada exitosamente");
            } else {
                showError("Error al eliminar la sección");
            }
            return success;
        }
        return false;
    }

    public boolean addScheduleToSection(SectionSchedule schedule) {
        if (!validateSchedule(schedule)) {
            return false;
        }

        boolean success = sectionDAO.addSchedule(schedule);
        if (success) {
            showSuccess("Horario agregado a la sección");
        } else {
            showError("Error al agregar el horario");
        }
        return success;
    }

    public List<Section> getAllSections() {
        return sectionDAO.getAll();
    }

    public Optional<Section> getSectionById(int id) {
        return sectionDAO.get(id);
    }

    public List<Section> getSectionsBySubject(int subjectId) {
        return sectionDAO.getBySubject(subjectId);
    }

    public List<Section> getSectionsByProfessor(int professorId) {
        List<Section> allSections = getAllSections();
        return allSections.stream()
                .filter(section -> section.getProfessorId() == professorId)
                .toList();
    }

    public boolean enrollStudentInSection(int studentId, int sectionId) {
        Optional<Section> sectionOpt = sectionDAO.get(sectionId);
        if (sectionOpt.isPresent()) {
            Section section = sectionOpt.get();
            if (section.canEnroll()) {
                return sectionDAO.incrementEnrollment(sectionId);
            } else {
                showError("La sección está llena o no está activa");
                return false;
            }
        }
        showError("Sección no encontrada");
        return false;
    }

    public boolean unenrollStudentFromSection(int studentId, int sectionId) {
        return sectionDAO.decrementEnrollment(sectionId);
    }

    public int countSections() {
        return sectionDAO.count();
    }

    public int countSectionsBySubject(int subjectId) {
        return sectionDAO.getBySubject(subjectId).size();
    }

    private boolean validateSection(Section section) {
        if (section.getSubjectId() <= 0) {
            showError("Debe seleccionar una materia válida");
            return false;
        }

        if (section.getSectionCode() == null || section.getSectionCode().trim().isEmpty()) {
            showError("El código de sección es obligatorio");
            return false;
        }

        if (section.getProfessorId() <= 0) {
            showError("Debe seleccionar un profesor válido");
            return false;
        }

        if (section.getCapacity() <= 0) {
            showError("La capacidad debe ser mayor a 0");
            return false;
        }

        if (section.getCurrentEnrollment() < 0) {
            showError("La inscripción actual no puede ser negativa");
            return false;
        }

        if (section.getCurrentEnrollment() > section.getCapacity()) {
            showError("La inscripción actual no puede ser mayor que la capacidad");
            return false;
        }

        return true;
    }

    private boolean validateSchedule(SectionSchedule schedule) {
        if (schedule.getSectionId() <= 0) {
            showError("Sección inválida");
            return false;
        }

        if (schedule.getDayOfWeek() == null || schedule.getDayOfWeek().trim().isEmpty()) {
            showError("El día de la semana es obligatorio");
            return false;
        }

        if (schedule.getStartTime() == null || schedule.getEndTime() == null) {
            showError("La hora de inicio y fin son obligatorias");
            return false;
        }

        // Validar formato de horas
        try {
            java.time.LocalTime start = java.time.LocalTime.parse(schedule.getStartTime());
            java.time.LocalTime end = java.time.LocalTime.parse(schedule.getEndTime());

            if (!start.isBefore(end)) {
                showError("La hora de inicio debe ser antes que la hora de fin");
                return false;
            }
        } catch (Exception e) {
            showError("Formato de hora inválido. Use HH:MM (24 horas)");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error de Validación", JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(null, message, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}