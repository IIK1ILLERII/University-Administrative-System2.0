package services;

import model.Student;
import model.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class StudentService {

    public boolean addStudent(Student student) {
        String sql = "INSERT INTO students (dni, first_name, last_name1, last_name2, age, gender, " +
                "email, phone, address, district, career, semester, date_of_birth, gpa) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getDni());
            pstmt.setString(2, student.getFirstName());
            pstmt.setString(3, student.getLastName1());
            pstmt.setString(4, student.getLastName2());
            pstmt.setInt(5, student.getAge());
            pstmt.setString(6, student.getGender());
            pstmt.setString(7, student.getEmail());
            pstmt.setString(8, student.getPhone());
            pstmt.setString(9, student.getAddress());
            pstmt.setString(10, student.getDistrict());
            pstmt.setString(11, student.getCareer());
            pstmt.setInt(12, student.getSemester());
            pstmt.setString(13, student.getDateOfBirth());
            pstmt.setDouble(14, student.getGpa());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean updateStudent(Student student) {
        String sql = "UPDATE students SET dni = ?, first_name = ?, last_name1 = ?, last_name2 = ?, " +
                "age = ?, gender = ?, email = ?, phone = ?, address = ?, district = ?, " +
                "career = ?, semester = ?, date_of_birth = ?, gpa = ?, status = ? " +
                "WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getDni());
            pstmt.setString(2, student.getFirstName());
            pstmt.setString(3, student.getLastName1());
            pstmt.setString(4, student.getLastName2());
            pstmt.setInt(5, student.getAge());
            pstmt.setString(6, student.getGender());
            pstmt.setString(7, student.getEmail());
            pstmt.setString(8, student.getPhone());
            pstmt.setString(9, student.getAddress());
            pstmt.setString(10, student.getDistrict());
            pstmt.setString(11, student.getCareer());
            pstmt.setInt(12, student.getSemester());
            pstmt.setString(13, student.getDateOfBirth());
            pstmt.setDouble(14, student.getGpa());
            pstmt.setString(15, student.getStatus());
            pstmt.setInt(16, student.getStudentId());

            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean deleteStudent(int studentId) {
        String sql = "DELETE FROM students WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, studentId);
            return pstmt.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students ORDER BY student_id";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                students.add(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public Optional<Student> getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE student_id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    // Métodos de búsqueda actualizados
    public List<Student> getStudentsByName(String name) {
        return searchStudents("first_name", name);
    }

    public List<Student> getStudentsByLastName1(String lastName1) {
        return searchStudents("last_name1", lastName1);
    }

    public List<Student> getStudentsByLastName2(String lastName2) {
        return searchStudents("last_name2", lastName2);
    }

    public Optional<Student> getStudentByDni(String dni) {
        String sql = "SELECT * FROM students WHERE dni = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, dni);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public List<Student> getStudentsByCareer(String career) {
        return searchStudents("career", career);
    }

    public Optional<Student> getStudentByEmail(String email) {
        String sql = "SELECT * FROM students WHERE email = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, email);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return Optional.of(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return Optional.empty();
    }

    public List<Student> getStudentsBySemester(int semester) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE semester = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, semester);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                students.add(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public List<Student> getStudentsByDistrict(String district) {
        return searchStudents("district", district);
    }

    public List<Student> getStudentsByGender(String gender) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE gender = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, gender);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                students.add(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public List<Student> getActiveStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE status = 'ACTIVE'";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                students.add(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    public int countStudents() {
        String sql = "SELECT COUNT(*) FROM students";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Nuevos métodos para estadísticas
    public long getStudentsCountByGender(String gender) {
        String sql = "SELECT COUNT(*) FROM students WHERE gender = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, gender);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getLong(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public List<String> getDistricts() {
        List<String> districts = new ArrayList<>();
        String sql = "SELECT DISTINCT district FROM students WHERE district IS NOT NULL";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                districts.add(rs.getString("district"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return districts;
    }

    public long getStudentsCountByDistrict(String district) {
        String sql = "SELECT COUNT(*) FROM students WHERE district = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, district);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getLong(1);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    // Método auxiliar para convertir ResultSet a Student
    private Student resultSetToStudent(ResultSet rs) throws SQLException {
        Student student = new Student();
        student.setStudentId(rs.getInt("student_id"));
        student.setDni(rs.getString("dni"));
        student.setFirstName(rs.getString("first_name"));
        student.setLastName1(rs.getString("last_name1"));
        student.setLastName2(rs.getString("last_name2"));
        student.setAge(rs.getInt("age"));
        student.setGender(rs.getString("gender"));
        student.setEmail(rs.getString("email"));
        student.setPhone(rs.getString("phone"));
        student.setAddress(rs.getString("address"));
        student.setDistrict(rs.getString("district"));
        student.setCareer(rs.getString("career"));
        student.setSemester(rs.getInt("semester"));
        student.setGpa(rs.getDouble("gpa"));
        student.setDateOfBirth(rs.getString("date_of_birth"));
        student.setEnrollmentDate(rs.getString("enrollment_date"));
        student.setStatus(rs.getString("status"));
        return student;
    }

    // Método auxiliar para búsquedas genéricas
    private List<Student> searchStudents(String column, String value) {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students WHERE " + column + " LIKE ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, "%" + value + "%");
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                students.add(resultSetToStudent(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }
}