package services;

import dao.SubjectDAO;
import dao.ClassScheduleDAO;
import model.Subject;
import model.ClassSchedule;
import model.DatabaseConnection;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class SubjectService {
    private final SubjectDAO subjectDAO;
    private final ClassScheduleDAO scheduleDAO;

    public SubjectService() {
        Connection conn = DatabaseConnection.getConnection();
        this.subjectDAO = new SubjectDAO(conn);
        this.scheduleDAO = new ClassScheduleDAO(conn);
    }

    public boolean addSubject(Subject subject) {
        if (!validateSubject(subject)) {
            return false;
        }

        if (subjectDAO.getByCode(subject.getCode()).isPresent()) {
            showError("El código de la materia ya está registrado");
            return false;
        }

        boolean success = subjectDAO.save(subject);
        if (success) {
            // Guardar horarios si existen
            for (ClassSchedule schedule : subject.getSchedules()) {
                schedule.setSubjectId(subject.getSubjectId());
                scheduleDAO.save(schedule);
            }
            showSuccess("Materia agregada exitosamente");
        } else {
            showError("Error al agregar la materia");
        }
        return success;
    }

    public boolean updateSubject(Subject subject) {
        if (!validateSubject(subject)) {
            return false;
        }

        Optional<Subject> existingSubject = subjectDAO.getByCode(subject.getCode());
        if (existingSubject.isPresent() && existingSubject.get().getSubjectId() != subject.getSubjectId()) {
            showError("El código de la materia ya está en uso por otra materia");
            return false;
        }

        boolean success = subjectDAO.update(subject);
        if (success) {
            showSuccess("Materia actualizada exitosamente");
        } else {
            showError("Error al actualizar la materia");
        }
        return success;
    }

    public boolean deleteSubject(int subjectId) {
        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de eliminar esta materia?\nSe eliminarán todos los horarios asociados.",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = subjectDAO.deleteById(subjectId);
            if (success) {
                showSuccess("Materia eliminada exitosamente");
            } else {
                showError("Error al eliminar la materia");
            }
            return success;
        }
        return false;
    }

    // Métodos para gestionar horarios
    public boolean addSchedule(ClassSchedule schedule) {
        if (!validateSchedule(schedule)) {
            return false;
        }

        // Verificar conflictos de horario
        if (scheduleDAO.hasTimeConflict(schedule.getProfessorId(), schedule.getDayOfWeek(),
                schedule.getStartTime(), schedule.getEndTime(), null)) {
            showError("El profesor tiene un conflicto de horario en ese día y hora");
            return false;
        }

        boolean success = scheduleDAO.save(schedule);
        if (success) {
            showSuccess("Horario agregado exitosamente");
        } else {
            showError("Error al agregar el horario");
        }
        return success;
    }

    public boolean updateSchedule(ClassSchedule schedule) {
        if (!validateSchedule(schedule)) {
            return false;
        }

        // Verificar conflictos de horario (excluyendo el horario actual)
        if (scheduleDAO.hasTimeConflict(schedule.getProfessorId(), schedule.getDayOfWeek(),
                schedule.getStartTime(), schedule.getEndTime(), schedule.getScheduleId())) {
            showError("El profesor tiene un conflicto de horario en ese día y hora");
            return false;
        }

        boolean success = scheduleDAO.update(schedule);
        if (success) {
            showSuccess("Horario actualizado exitosamente");
        } else {
            showError("Error al actualizar el horario");
        }
        return success;
    }

    public boolean deleteSchedule(int scheduleId) {
        int confirm = JOptionPane.showConfirmDialog(null,
                "¿Está seguro de eliminar este horario?",
                "Confirmar Eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (confirm == JOptionPane.YES_OPTION) {
            boolean success = scheduleDAO.deleteById(scheduleId);
            if (success) {
                showSuccess("Horario eliminado exitosamente");
            } else {
                showError("Error al eliminar el horario");
            }
            return success;
        }
        return false;
    }

    public List<Subject> getAllSubjects() {
        return subjectDAO.getAll();
    }

    public Optional<Subject> getSubjectById(int id) {
        return subjectDAO.get(id);
    }

    public Optional<Subject> getSubjectByCode(String code) {
        return subjectDAO.getByCode(code);
    }

    public List<Subject> getSubjectsByProfessor(int professorId) {
        return subjectDAO.getByProfessor(professorId);
    }

    public List<Subject> getSubjectsByDepartment(String department) {
        return subjectDAO.getByDepartment(department);
    }

    public List<Subject> getBasicSubjects() {
        return subjectDAO.getByDifficultyLevel("BASIC");
    }

    public List<Subject> getIntermediateSubjects() {
        return subjectDAO.getByDifficultyLevel("INTERMEDIATE");
    }

    public List<Subject> getAdvancedSubjects() {
        return subjectDAO.getByDifficultyLevel("ADVANCED");
    }

    public List<Subject> getSubjectsByDifficultyLevel(String difficultyLevel) {
        return subjectDAO.getByDifficultyLevel(difficultyLevel);
    }

    public List<Subject> getSubjectsWithSchedules() {
        return subjectDAO.getSubjectsWithSchedules();
    }

    // Métodos para horarios
    public List<ClassSchedule> getSchedulesBySubject(int subjectId) {
        return scheduleDAO.getBySubject(subjectId);
    }

    public List<ClassSchedule> getSchedulesByProfessor(int professorId) {
        return scheduleDAO.getByProfessor(professorId);
    }

    public List<ClassSchedule> getWeeklySchedule() {
        return scheduleDAO.getWeeklySchedule();
    }

    public List<ClassSchedule> getSchedulesByDay(String dayOfWeek) {
        return scheduleDAO.getByDayOfWeek(dayOfWeek);
    }

    public Optional<ClassSchedule> getScheduleById(int scheduleId) {
        return scheduleDAO.get(scheduleId);
    }

    public int countSubjects() {
        return subjectDAO.count();
    }

    public int countSubjectsByDepartment(String department) {
        return getSubjectsByDepartment(department).size();
    }

    public int countSubjectsByProfessor(int professorId) {
        return getSubjectsByProfessor(professorId).size();
    }

    public int countActiveSchedules() {
        return scheduleDAO.count();
    }

    public List<String> getAllSubjectDepartments() {
        List<Subject> subjects = getAllSubjects();
        return subjects.stream()
                .map(Subject::getDepartment)
                .distinct()
                .sorted()
                .toList();
    }

    public List<Subject> getAllActiveSubjects() {
        List<Subject> allSubjects = getAllSubjects();
        return allSubjects.stream()
                .filter(subject -> "ACTIVE".equals(subject.getStatus()))
                .collect(Collectors.toList());
    }

    public List<String> getAllDifficultyLevels() {
        return List.of("BASIC", "INTERMEDIATE", "ADVANCED");
    }

    public List<String> getDaysOfWeek() {
        return List.of("LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO");
    }

    public List<String> getTimeSlots() {
        // Generar slots de tiempo de 8:00 a 22:00 en intervalos de 30 minutos
        List<String> timeSlots = new ArrayList<>();
        for (int hour = 8; hour <= 22; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                String time = String.format("%02d:%02d", hour, minute);
                timeSlots.add(time);
            }
        }
        return timeSlots;
    }

    private boolean validateSubject(Subject subject) {
        if (subject.getSubjectName() == null || subject.getSubjectName().trim().isEmpty()) {
            showError("El nombre de la materia es obligatorio");
            return false;
        }

        if (subject.getCode() == null || subject.getCode().trim().isEmpty()) {
            showError("El código de la materia es obligatorio");
            return false;
        }

        if (subject.getCredits() < 1 || subject.getCredits() > 10) {
            showError("Los créditos deben estar entre 1 y 10");
            return false;
        }

        if (subject.getDepartment() == null || subject.getDepartment().trim().isEmpty()) {
            showError("El departamento es obligatorio");
            return false;
        }

        if (subject.getDifficultyLevel() == null || subject.getDifficultyLevel().trim().isEmpty()) {
            showError("El nivel de dificultad es obligatorio");
            return false;
        }

        if (!getAllDifficultyLevels().contains(subject.getDifficultyLevel().toUpperCase())) {
            showError("El nivel de dificultad debe ser: BASIC, INTERMEDIATE o ADVANCED");
            return false;
        }

        if (subject.getHoursPerWeek() < 1 || subject.getHoursPerWeek() > 20) {
            showError("Las horas por semana deben estar entre 1 y 20");
            return false;
        }

        return true;
    }

    private boolean validateSchedule(ClassSchedule schedule) {
        if (schedule.getSubjectId() <= 0) {
            showError("Debe seleccionar una materia válida");
            return false;
        }

        if (schedule.getProfessorId() <= 0) {
            showError("Debe seleccionar un profesor válido");
            return false;
        }

        if (schedule.getDayOfWeek() == null || schedule.getDayOfWeek().trim().isEmpty()) {
            showError("El día de la semana es obligatorio");
            return false;
        }

        if (schedule.getStartTime() == null || schedule.getEndTime() == null) {
            showError("La hora de inicio y fin son obligatorias");
            return false;
        }

        // Validar que la hora de inicio sea antes que la de fin
        try {
            java.time.LocalTime start = java.time.LocalTime.parse(schedule.getStartTime());
            java.time.LocalTime end = java.time.LocalTime.parse(schedule.getEndTime());

            if (!start.isBefore(end)) {
                showError("La hora de inicio debe ser antes que la hora de fin");
                return false;
            }

            // Validar que esté dentro del horario permitido (8:00 - 22:00)
            java.time.LocalTime minTime = java.time.LocalTime.of(8, 0);
            java.time.LocalTime maxTime = java.time.LocalTime.of(22, 0);

            if (start.isBefore(minTime) || end.isAfter(maxTime)) {
                showError("El horario debe estar entre las 8:00 y las 22:00");
                return false;
            }

        } catch (Exception e) {
            showError("Formato de hora inválido. Use HH:MM (24 horas)");
            return false;
        }

        return true;
    }

    private void showError(String message) {
        JOptionPane.showMessageDialog(null, message, "Error de Validación", JOptionPane.ERROR_MESSAGE);
    }

    private void showSuccess(String message) {
        JOptionPane.showMessageDialog(null, message, "Éxito", JOptionPane.INFORMATION_MESSAGE);
    }
}