package views;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class LoginDialog extends JDialog {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnLogin;
    private JButton btnCancel;
    private boolean authenticated = false;

    public LoginDialog(Frame parent) {
        super(parent, "Sistema Universitario - Login", true);
        initializeComponents();
        setupEvents();
        pack();
        setLocationRelativeTo(parent);
        setResizable(false);
    }

    private void initializeComponents() {
        setLayout(new BorderLayout(10, 10));

        // Panel principal
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        // Título
        JLabel lblTitle = new JLabel("Sistema Administrativo Universitario", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 16));
        lblTitle.setForeground(new Color(0, 70, 130));
        mainPanel.add(lblTitle, BorderLayout.NORTH);

        // Panel de campos
        JPanel fieldsPanel = new JPanel(new GridLayout(2, 2, 10, 10));

        JLabel lblUser = new JLabel("Usuario:");
        txtUsername = new JTextField(15);

        JLabel lblPass = new JLabel("Contraseña:");
        txtPassword = new JPasswordField(15);

        fieldsPanel.add(lblUser);
        fieldsPanel.add(txtUsername);
        fieldsPanel.add(lblPass);
        fieldsPanel.add(txtPassword);

        mainPanel.add(fieldsPanel, BorderLayout.CENTER);

        // Panel de información de usuarios
        JPanel infoPanel = new JPanel();
        infoPanel.setBorder(BorderFactory.createTitledBorder("Usuarios"));
        infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));

        JLabel infoLabel = new JLabel("<html>"
                + "• admin / admin123 (Administrador)<br>"
                + "• matricula / mat123 (Matriculador)<br>"
                + "• contrata / cont123 (Contratador)<br>"
                + "• inscribe / ins123 (Inscriptor)"
                + "</html>");
        infoLabel.setFont(new Font("Arial", Font.PLAIN, 10));
        infoPanel.add(infoLabel);

        mainPanel.add(infoPanel, BorderLayout.NORTH);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout());
        btnLogin = new JButton("Iniciar Sesión");
        btnCancel = new JButton("Cancelar");

        // Estilos de botones
        btnLogin.setBackground(new Color(0, 120, 215));
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);

        buttonPanel.add(btnLogin);
        buttonPanel.add(btnCancel);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    private void setupEvents() {
        btnLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                attemptLogin();
            }
        });

        btnCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                authenticated = false;
                dispose();
            }
        });

        // Eventos de teclado
        txtPassword.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    attemptLogin();
                }
            }
        });

        txtUsername.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    txtPassword.requestFocus();
                }
            }
        });
    }

    private void attemptLogin() {
        String username = txtUsername.getText().trim();
        String password = new String(txtPassword.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Por favor, complete todos los campos",
                    "Error de validación",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        authenticated = true;
        dispose();
    }

    public String getUsername() {
        return txtUsername.getText().trim();
    }

    public String getPassword() {
        return new String(txtPassword.getPassword());
    }

    public boolean isAuthenticated() {
        return authenticated;
    }
}