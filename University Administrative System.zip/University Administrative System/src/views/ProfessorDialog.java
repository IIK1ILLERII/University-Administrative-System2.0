package views;

import controller.ProfessorController;
import model.Professor;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ProfessorDialog extends JDialog {
    private JTextField txtFirstName, txtPaternalLastName, txtMaternalLastName;
    private JTextField txtEmail, txtPhone, txtDni, txtAge, txtDistrict;
    private JTextField txtDepartment, txtSpecialty, txtFixedSalary, txtHours, txtHourlyRate;
    private JComboBox<String> comboGender, comboType, comboStatus;
    private JPanel timeSpecificPanel;
    private ProfessorController controller;
    private ProfessorsPanel parentPanel;
    private Professor existingProfessor;

    public ProfessorDialog(Frame owner, String title, ProfessorController controller, ProfessorsPanel parentPanel) {
        this(owner, title, controller, parentPanel, null);
    }

    public ProfessorDialog(Frame owner, String title, ProfessorController controller, ProfessorsPanel parentPanel, Professor existingProfessor) {
        super(owner, title, true);
        this.controller = controller;
        this.parentPanel = parentPanel;
        this.existingProfessor = existingProfessor;
        initComponents();
        pack();
        setLocationRelativeTo(owner);
        setSize(500, 600); // Tamaño fijo para mejor visualización
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setResizable(true);

        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createTitledBorder("Información Personal"));

        // Campos básicos
        txtFirstName = new JTextField();
        txtPaternalLastName = new JTextField();
        txtMaternalLastName = new JTextField();
        txtDni = new JTextField();
        txtAge = new JTextField();
        comboGender = new JComboBox<>(new String[]{"MASCULINO", "FEMENINO"});
        txtDistrict = new JTextField();
        txtEmail = new JTextField();
        txtPhone = new JTextField();
        txtDepartment = new JTextField();
        txtSpecialty = new JTextField();

        // Tipo de profesor y estado
        comboType = new JComboBox<>(new String[]{"TIEMPO_COMPLETO", "MEDIO_TIEMPO"});
        comboStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE", "ON_LEAVE"});

        // Campos específicos por tipo
        txtFixedSalary = new JTextField("0.0");
        txtHours = new JTextField("0");
        txtHourlyRate = new JTextField("0.0");

        // Agregar campos al formulario
        formPanel.add(new JLabel("Nombre:"));
        formPanel.add(txtFirstName);
        formPanel.add(new JLabel("Apellido Paterno:"));
        formPanel.add(txtPaternalLastName);
        formPanel.add(new JLabel("Apellido Materno:"));
        formPanel.add(txtMaternalLastName);
        formPanel.add(new JLabel("DNI:"));
        formPanel.add(txtDni);
        formPanel.add(new JLabel("Edad:"));
        formPanel.add(txtAge);
        formPanel.add(new JLabel("Sexo:"));
        formPanel.add(comboGender);
        formPanel.add(new JLabel("Distrito:"));
        formPanel.add(txtDistrict);
        formPanel.add(new JLabel("Email:"));
        formPanel.add(txtEmail);
        formPanel.add(new JLabel("Teléfono:"));
        formPanel.add(txtPhone);
        formPanel.add(new JLabel("Departamento:"));
        formPanel.add(txtDepartment);
        formPanel.add(new JLabel("Especialidad:"));
        formPanel.add(txtSpecialty);
        formPanel.add(new JLabel("Tipo de Profesor:"));
        formPanel.add(comboType);
        formPanel.add(new JLabel("Estado:"));
        formPanel.add(comboStatus);

        mainPanel.add(formPanel, BorderLayout.NORTH);

        // Panel para campos específicos del tipo
        timeSpecificPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        timeSpecificPanel.setBorder(BorderFactory.createTitledBorder("Información Laboral"));
        updateTimeSpecificPanel();

        // Listener para cambiar entre tipos de profesor
        comboType.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                if (e.getStateChange() == ItemEvent.SELECTED) {
                    updateTimeSpecificPanel();
                    revalidate();
                    repaint();
                    pack();
                }
            }
        });

        mainPanel.add(timeSpecificPanel, BorderLayout.CENTER);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = new JButton("Guardar");
        JButton btnCancel = new JButton("Cancelar");

        btnSave.addActionListener(e -> saveProfessor());
        btnCancel.addActionListener(e -> dispose());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);

        add(mainPanel, BorderLayout.CENTER);
        add(buttonPanel, BorderLayout.SOUTH);

        // Si estamos editando, cargar datos existentes
        if (existingProfessor != null) {
            loadProfessorData();
        }
    }

    private void updateTimeSpecificPanel() {
        timeSpecificPanel.removeAll();
        String type = (String) comboType.getSelectedItem();

        if ("TIEMPO_COMPLETO".equals(type)) {
            timeSpecificPanel.add(new JLabel("Salario Fijo (S/.):"));
            timeSpecificPanel.add(txtFixedSalary);
            // Limpiar campos de medio tiempo
            txtHours.setText("0");
            txtHourlyRate.setText("0.0");
        } else {
            timeSpecificPanel.add(new JLabel("Horas por Semana:"));
            timeSpecificPanel.add(txtHours);
            timeSpecificPanel.add(new JLabel("Tarifa por Hora (S/.):"));
            timeSpecificPanel.add(txtHourlyRate);
            // Limpiar campo de salario fijo
            txtFixedSalary.setText("0.0");

            // Agregar label informativo
            JLabel lblInfo = new JLabel("Salario estimado mensual: S/.0.00");
            timeSpecificPanel.add(new JLabel(""));
            timeSpecificPanel.add(lblInfo);

            // Actualizar salario estimado cuando cambien horas o tarifa
            txtHours.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                public void changedUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
                public void insertUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
            });

            txtHourlyRate.getDocument().addDocumentListener(new javax.swing.event.DocumentListener() {
                public void changedUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
                public void removeUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
                public void insertUpdate(javax.swing.event.DocumentEvent e) { updateEstimatedSalary(lblInfo); }
            });
        }

        timeSpecificPanel.revalidate();
        timeSpecificPanel.repaint();
    }

    private void updateEstimatedSalary(JLabel lblInfo) {
        try {
            int hours = Integer.parseInt(txtHours.getText());
            double rate = Double.parseDouble(txtHourlyRate.getText());
            double monthlySalary = hours * rate * 4; // 4 semanas
            lblInfo.setText(String.format("Salario estimado mensual: S/.%.2f", monthlySalary));
        } catch (NumberFormatException e) {
            lblInfo.setText("Salario estimado mensual: S/.0.00");
        }
    }

    private void loadProfessorData() {
        txtFirstName.setText(existingProfessor.getFirstName());
        txtPaternalLastName.setText(existingProfessor.getPaternalLastName());
        txtMaternalLastName.setText(existingProfessor.getMaternalLastName());
        txtDni.setText(existingProfessor.getDni());
        txtAge.setText(String.valueOf(existingProfessor.getAge()));
        comboGender.setSelectedItem(existingProfessor.getGender());
        txtDistrict.setText(existingProfessor.getDistrict());
        txtEmail.setText(existingProfessor.getEmail());
        txtPhone.setText(existingProfessor.getPhone());
        txtDepartment.setText(existingProfessor.getDepartment());
        txtSpecialty.setText(existingProfessor.getSpecialty());
        comboType.setSelectedItem(existingProfessor.getProfessorType());
        comboStatus.setSelectedItem(existingProfessor.getStatus());

        if ("TIEMPO_COMPLETO".equals(existingProfessor.getProfessorType())) {
            txtFixedSalary.setText(String.valueOf(existingProfessor.getFixedSalary()));
        } else {
            txtHours.setText(String.valueOf(existingProfessor.getHoursPerWeek()));
            txtHourlyRate.setText(String.valueOf(existingProfessor.getHourlyRate()));
        }
    }

    private void saveProfessor() {
        try {
            // Validaciones básicas
            if (txtFirstName.getText().trim().isEmpty() ||
                    txtPaternalLastName.getText().trim().isEmpty() ||
                    txtMaternalLastName.getText().trim().isEmpty() ||
                    txtDni.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Por favor complete todos los campos obligatorios",
                        "Error de Validación", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success;
            if (existingProfessor == null) {
                // Agregar nuevo profesor
                success = controller.addProfessor(
                        txtFirstName.getText().trim(),
                        txtPaternalLastName.getText().trim(),
                        txtMaternalLastName.getText().trim(),
                        txtEmail.getText().trim(),
                        txtPhone.getText().trim(),
                        txtDni.getText().trim(),
                        (String) comboGender.getSelectedItem(),
                        Integer.parseInt(txtAge.getText().trim()),
                        txtDistrict.getText().trim(),
                        txtDepartment.getText().trim(),
                        txtSpecialty.getText().trim(),
                        (String) comboType.getSelectedItem(),
                        Double.parseDouble(txtFixedSalary.getText().trim()),
                        Integer.parseInt(txtHours.getText().trim()),
                        Double.parseDouble(txtHourlyRate.getText().trim()),
                        (String) comboStatus.getSelectedItem()
                );
            } else {
                // Actualizar profesor existente
                success = controller.updateProfessor(
                        existingProfessor.getProfessorId(),
                        txtFirstName.getText().trim(),
                        txtPaternalLastName.getText().trim(),
                        txtMaternalLastName.getText().trim(),
                        txtEmail.getText().trim(),
                        txtPhone.getText().trim(),
                        txtDni.getText().trim(),
                        (String) comboGender.getSelectedItem(),
                        Integer.parseInt(txtAge.getText().trim()),
                        txtDistrict.getText().trim(),
                        txtDepartment.getText().trim(),
                        txtSpecialty.getText().trim(),
                        (String) comboType.getSelectedItem(),
                        Double.parseDouble(txtFixedSalary.getText().trim()),
                        Integer.parseInt(txtHours.getText().trim()),
                        Double.parseDouble(txtHourlyRate.getText().trim()),
                        (String) comboStatus.getSelectedItem()
                );
            }

            if (success) {
                parentPanel.loadProfessors();
                dispose();
                JOptionPane.showMessageDialog(this,
                        existingProfessor == null ? "Profesor agregado exitosamente" : "Profesor actualizado exitosamente",
                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Error en el formato de números (edad, salario, horas, tarifa).\nAsegúrese de ingresar valores numéricos válidos.",
                    "Error de Formato", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error al guardar: " + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }
}