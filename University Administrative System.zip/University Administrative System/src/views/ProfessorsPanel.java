package views;

import controller.ProfessorController;
import model.Professor;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Optional;

public class ProfessorsPanel extends JPanel {
    private JTable fullTimeTable, partTimeTable;
    private DefaultTableModel fullTimeModel, partTimeModel;
    private JTextField txtSearch;
    private JComboBox<String> comboSearchType;
    private JButton btnSearch, btnAdd, btnEdit, btnDelete, btnRefresh;
    private ProfessorController professorController;
    private JTabbedPane tabbedPane;

    public ProfessorsPanel() {
        professorController = new ProfessorController();
        initComponents();
        loadProfessors();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel topPanel = new JPanel(new BorderLayout(10, 10));

        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.add(new JLabel("Buscar:"));
        txtSearch = new JTextField(20);
        searchPanel.add(txtSearch);

        comboSearchType = new JComboBox<>(new String[]{"Nombre", "Apellido Paterno", "Departamento", "DNI"});
        searchPanel.add(comboSearchType);

        btnSearch = new JButton("🔍 Buscar");
        btnSearch.addActionListener(e -> searchProfessors());
        searchPanel.add(btnSearch);

        topPanel.add(searchPanel, BorderLayout.WEST);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnAdd = new JButton("➕ Agregar");
        btnEdit = new JButton("✏️ Editar");
        btnDelete = new JButton("🗑️ Eliminar");
        btnRefresh = new JButton("🔄 Actualizar");

        btnAdd.addActionListener(e -> showAddProfessorDialog());
        btnEdit.addActionListener(e -> showEditProfessorDialog());
        btnDelete.addActionListener(e -> deleteProfessor());
        btnRefresh.addActionListener(e -> loadProfessors());

        actionPanel.add(btnAdd);
        actionPanel.add(btnEdit);
        actionPanel.add(btnDelete);
        actionPanel.add(btnRefresh);

        topPanel.add(actionPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);

        // Crear pestañas para los diferentes tipos de profesores
        tabbedPane = new JTabbedPane();

        // Tabla para Profesores Tiempo Completo
        fullTimeModel = new DefaultTableModel();
        String[] fullTimeColumns = {
                "ID", "Nombre", "Apellido Paterno", "Apellido Materno",
                "DNI", "Edad", "Sexo", "Distrito", "Departamento",
                "Especialidad", "Salario Fijo", "Estado"
        };
        for (String column : fullTimeColumns) {
            fullTimeModel.addColumn(column);
        }
        fullTimeTable = new JTable(fullTimeModel);
        fullTimeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane fullTimeScroll = new JScrollPane(fullTimeTable);
        fullTimeScroll.setBorder(BorderFactory.createTitledBorder("Profesores de Tiempo Completo"));
        tabbedPane.addTab("🏢 Tiempo Completo", fullTimeScroll);

        // Tabla para Profesores Medio Tiempo
        partTimeModel = new DefaultTableModel();
        String[] partTimeColumns = {
                "ID", "Nombre", "Apellido Paterno", "Apellido Materno",
                "DNI", "Edad", "Sexo", "Distrito", "Departamento",
                "Especialidad", "Horas/Semana", "Tarifa/Hora", "Salario Estimado", "Estado"
        };
        for (String column : partTimeColumns) {
            partTimeModel.addColumn(column);
        }
        partTimeTable = new JTable(partTimeModel);
        partTimeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane partTimeScroll = new JScrollPane(partTimeTable);
        partTimeScroll.setBorder(BorderFactory.createTitledBorder("Profesores de Medio Tiempo"));
        tabbedPane.addTab("⏱️ Medio Tiempo", partTimeScroll);

        add(tabbedPane, BorderLayout.CENTER);
        add(createStatsPanel(), BorderLayout.SOUTH);
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Estadísticas"));

        int total = professorController.getTotalProfessors();
        int fullTime = professorController.getProfessorsCountByType("TIEMPO_COMPLETO");
        int partTime = professorController.getProfessorsCountByType("MEDIO_TIEMPO");

        JLabel lblTotal = new JLabel("Total Profesores: " + total);
        JLabel lblFullTime = new JLabel("Tiempo Completo: " + fullTime);
        JLabel lblPartTime = new JLabel("Medio Tiempo: " + partTime);

        statsPanel.add(lblTotal);
        statsPanel.add(Box.createHorizontalStrut(20));
        statsPanel.add(lblFullTime);
        statsPanel.add(Box.createHorizontalStrut(20));
        statsPanel.add(lblPartTime);

        return statsPanel;
    }

    public void loadProfessors() {
        // Cargar profesores tiempo completo
        List<Professor> fullTimeProfessors = professorController.getProfessorsByType("TIEMPO_COMPLETO");
        fullTimeModel.setRowCount(0);
        for (Professor professor : fullTimeProfessors) {
            fullTimeModel.addRow(new Object[]{
                    professor.getProfessorId(),
                    professor.getFirstName(),
                    professor.getPaternalLastName(),
                    professor.getMaternalLastName(),
                    professor.getDni(),
                    professor.getAge(),
                    professor.getGender(),
                    professor.getDistrict(),
                    professor.getDepartment(),
                    professor.getSpecialty(),
                    String.format("S/.%.2f", professor.getFixedSalary()),
                    professor.getStatus()
            });
        }

        // Cargar profesores medio tiempo
        List<Professor> partTimeProfessors = professorController.getProfessorsByType("MEDIO_TIEMPO");
        partTimeModel.setRowCount(0);
        for (Professor professor : partTimeProfessors) {
            double estimatedSalary = professor.getHoursPerWeek() * professor.getHourlyRate() * 4; // Mensual
            partTimeModel.addRow(new Object[]{
                    professor.getProfessorId(),
                    professor.getFirstName(),
                    professor.getPaternalLastName(),
                    professor.getMaternalLastName(),
                    professor.getDni(),
                    professor.getAge(),
                    professor.getGender(),
                    professor.getDistrict(),
                    professor.getDepartment(),
                    professor.getSpecialty(),
                    professor.getHoursPerWeek(),
                    String.format("S/.%.2f", professor.getHourlyRate()),
                    String.format("S/.%.2f", estimatedSalary),
                    professor.getStatus()
            });
        }
    }

    private void searchProfessors() {
        String criteria = txtSearch.getText().trim();
        String searchType = comboSearchType.getSelectedItem().toString();

        if (criteria.isEmpty()) {
            loadProfessors();
            return;
        }

        List<Professor> professors = professorController.searchProfessors(criteria, searchType);
        updateTablesWithFilteredResults(professors);
    }

    private void updateTablesWithFilteredResults(List<Professor> professors) {
        fullTimeModel.setRowCount(0);
        partTimeModel.setRowCount(0);

        for (Professor professor : professors) {
            if ("TIEMPO_COMPLETO".equals(professor.getProfessorType())) {
                fullTimeModel.addRow(new Object[]{
                        professor.getProfessorId(),
                        professor.getFirstName(),
                        professor.getPaternalLastName(),
                        professor.getMaternalLastName(),
                        professor.getDni(),
                        professor.getAge(),
                        professor.getGender(),
                        professor.getDistrict(),
                        professor.getDepartment(),
                        professor.getSpecialty(),
                        String.format("S/.%.2f", professor.getFixedSalary()),
                        professor.getStatus()
                });
            } else {
                double estimatedSalary = professor.getHoursPerWeek() * professor.getHourlyRate() * 4;
                partTimeModel.addRow(new Object[]{
                        professor.getProfessorId(),
                        professor.getFirstName(),
                        professor.getPaternalLastName(),
                        professor.getMaternalLastName(),
                        professor.getDni(),
                        professor.getAge(),
                        professor.getGender(),
                        professor.getDistrict(),
                        professor.getDepartment(),
                        professor.getSpecialty(),
                        professor.getHoursPerWeek(),
                        String.format("S/.%.2f", professor.getHourlyRate()),
                        String.format("S/.%.2f", estimatedSalary),
                        professor.getStatus()
                });
            }
        }
    }

    private void showAddProfessorDialog() {
        ProfessorDialog dialog = new ProfessorDialog(null, "Agregar Nuevo Profesor", professorController, this);
        dialog.setVisible(true);
    }

    private void showEditProfessorDialog() {
        JTable currentTable = getCurrentTable();
        if (currentTable == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un profesor para editar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int selectedRow = currentTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un profesor para editar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int professorId = (int) currentTable.getValueAt(selectedRow, 0);
        Optional<Professor> professorOpt = professorController.getProfessorById(professorId);

        if (professorOpt.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo cargar los datos del profesor", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        Professor professor = professorOpt.get();
        ProfessorDialog dialog = new ProfessorDialog(null, "Editar Profesor", professorController, this, professor);
        dialog.setVisible(true);
    }

    private void deleteProfessor() {
        JTable currentTable = getCurrentTable();
        if (currentTable == null) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un profesor para eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int selectedRow = currentTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un profesor para eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int professorId = (int) currentTable.getValueAt(selectedRow, 0);
        boolean success = professorController.deleteProfessor(professorId);

        if (success) {
            loadProfessors();
        }
    }

    private JTable getCurrentTable() {
        int selectedTab = tabbedPane.getSelectedIndex();
        return selectedTab == 0 ? fullTimeTable : partTimeTable;
    }
}