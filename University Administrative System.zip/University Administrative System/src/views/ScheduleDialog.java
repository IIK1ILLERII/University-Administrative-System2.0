package views;

import controller.SubjectController;
import model.ClassSchedule;
import model.Subject;
import javax.swing.*;
import java.awt.*;
import java.util.List;
import java.util.Optional;

public class ScheduleDialog extends JDialog {
    private JComboBox<Subject> comboSubject;
    private JComboBox<String> comboDay;
    private JComboBox<String> comboStartTime;
    private JComboBox<String> comboEndTime;
    private JTextField txtClassroom;
    private JComboBox<String> comboStatus;
    private JComboBox<String> comboProfessor;

    private SubjectController controller;
    private ClassSchedule existingSchedule;
    private boolean isEditMode;

    public ScheduleDialog(Frame owner, SubjectController controller) {
        this(owner, controller, null);
    }

    public ScheduleDialog(Frame owner, SubjectController controller, ClassSchedule existingSchedule) {
        super(owner, existingSchedule == null ? "Agregar Horario" : "Editar Horario", true);
        this.controller = controller;
        this.existingSchedule = existingSchedule;
        this.isEditMode = existingSchedule != null;
        initComponents();
        pack();
        setLocationRelativeTo(owner);
        setSize(500, 400);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Combo para materias
        comboSubject = new JComboBox<>();
        loadSubjects();
        formPanel.add(new JLabel("Materia:*"));
        formPanel.add(comboSubject);

        // Combo para días de la semana
        comboDay = new JComboBox<>(new String[]{"LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO"});
        formPanel.add(new JLabel("Día:*"));
        formPanel.add(comboDay);

        // Combos para horas
        comboStartTime = new JComboBox<>();
        comboEndTime = new JComboBox<>();
        loadTimeSlots();

        formPanel.add(new JLabel("Hora Inicio:*"));
        formPanel.add(comboStartTime);
        formPanel.add(new JLabel("Hora Fin:*"));
        formPanel.add(comboEndTime);

        // Campo para aula
        txtClassroom = new JTextField();
        formPanel.add(new JLabel("Aula:"));
        formPanel.add(txtClassroom);

        // Combo para estado (solo en edición)
        comboStatus = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});
        if (isEditMode) {
            formPanel.add(new JLabel("Estado:"));
            formPanel.add(comboStatus);
        }

        add(formPanel, BorderLayout.CENTER);

        // Panel de información
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("* Campos obligatorios"));
        add(infoPanel, BorderLayout.NORTH);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = new JButton(isEditMode ? "Actualizar" : "Guardar");
        JButton btnCancel = new JButton("Cancelar");

        btnSave.addActionListener(e -> saveSchedule());
        btnCancel.addActionListener(e -> dispose());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);

        add(buttonPanel, BorderLayout.SOUTH);

        // Si estamos editando, cargar datos existentes
        if (isEditMode) {
            loadScheduleData();
        }
    }

    private void loadSubjects() {
        List<Subject> subjects = controller.getAllActiveSubjects();
        comboSubject.removeAllItems();

        // Configurar renderer personalizado
        comboSubject.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Subject) {
                    Subject subject = (Subject) value;
                    setText(String.format("%s - %s", subject.getCode(), subject.getSubjectName()));
                }
                return this;
            }
        });

        for (Subject subject : subjects) {
            comboSubject.addItem(subject);
        }

        // Seleccionar el primer item si existe
        if (comboSubject.getItemCount() > 0) {
            comboSubject.setSelectedIndex(0);
        }
    }

    private void loadTimeSlots() {
        List<String> timeSlots = controller.getTimeSlots();
        for (String time : timeSlots) {
            comboStartTime.addItem(time);
            comboEndTime.addItem(time);
        }

        // Establecer valores por defecto
        comboStartTime.setSelectedItem("08:00");
        comboEndTime.setSelectedItem("10:00");
    }

    private void loadScheduleData() {
        if (existingSchedule != null) {
            // Seleccionar la materia correspondiente
            for (int i = 0; i < comboSubject.getItemCount(); i++) {
                Subject subject = comboSubject.getItemAt(i);
                if (subject.getSubjectId() == existingSchedule.getSubjectId()) {
                    comboSubject.setSelectedIndex(i);
                    break;
                }
            }

            comboDay.setSelectedItem(existingSchedule.getDayOfWeek());
            comboStartTime.setSelectedItem(existingSchedule.getStartTime());
            comboEndTime.setSelectedItem(existingSchedule.getEndTime());
            txtClassroom.setText(existingSchedule.getClassroom());
            comboStatus.setSelectedItem(existingSchedule.getStatus());
        }
    }

    private void saveSchedule() {
        try {
            // Validar selección de materia
            if (comboSubject.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Seleccione una materia", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Subject selectedSubject = (Subject) comboSubject.getSelectedItem();

            // Validar campos obligatorios
            if (comboDay.getSelectedItem() == null || comboStartTime.getSelectedItem() == null ||
                    comboEndTime.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Complete todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success;
            if (isEditMode) {
                success = controller.updateSchedule(
                        existingSchedule.getScheduleId(),
                        selectedSubject.getSubjectId(),
                        selectedSubject.getProfessorId(),
                        (String) comboDay.getSelectedItem(),
                        (String) comboStartTime.getSelectedItem(),
                        (String) comboEndTime.getSelectedItem(),
                        txtClassroom.getText().trim(),
                        (String) comboStatus.getSelectedItem()
                );
            } else {
                success = controller.addSchedule(
                        selectedSubject.getSubjectId(),
                        selectedSubject.getProfessorId(),
                        (String) comboDay.getSelectedItem(),
                        (String) comboStartTime.getSelectedItem(),
                        (String) comboEndTime.getSelectedItem(),
                        txtClassroom.getText().trim()
                );
            }

            if (success) {
                dispose();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}