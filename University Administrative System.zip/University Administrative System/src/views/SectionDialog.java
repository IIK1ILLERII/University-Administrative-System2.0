package views;

import controller.SectionController;
import controller.SubjectController;
import controller.ProfessorController;
import model.Section;
import model.Subject;
import model.Professor;
import javax.swing.*;
import java.awt.*;
import java.util.List;

public class SectionDialog extends JDialog {
    private JComboBox<Subject> comboSubject;
    private JTextField txtSectionCode;
    private JComboBox<Professor> comboProfessor;
    private JSpinner spinnerCapacity;
    private JComboBox<String> comboStatus;

    private SectionController sectionController;
    private SubjectController subjectController;
    private ProfessorController professorController;
    private Section existingSection;
    private boolean isEditMode;

    public SectionDialog(Frame owner, SectionController sectionController,
                         SubjectController subjectController, ProfessorController professorController) {
        this(owner, sectionController, subjectController, professorController, null);
    }

    public SectionDialog(Frame owner, SectionController sectionController,
                         SubjectController subjectController, ProfessorController professorController,
                         Section existingSection) {
        super(owner, existingSection == null ? "Crear Sección" : "Editar Sección", true);
        this.sectionController = sectionController;
        this.subjectController = subjectController;
        this.professorController = professorController;
        this.existingSection = existingSection;
        this.isEditMode = existingSection != null;
        initComponents();
        pack();
        setLocationRelativeTo(owner);
        setSize(500, 400);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Combo para materias
        comboSubject = new JComboBox<>();
        loadSubjects();
        formPanel.add(new JLabel("Materia:*"));
        formPanel.add(comboSubject);

        // Campo para código de sección
        txtSectionCode = new JTextField();
        formPanel.add(new JLabel("Código Sección:*"));
        formPanel.add(txtSectionCode);

        // Combo para profesores
        comboProfessor = new JComboBox<>();
        loadProfessors();
        formPanel.add(new JLabel("Profesor:*"));
        formPanel.add(comboProfessor);

        // Spinner para capacidad
        spinnerCapacity = new JSpinner(new SpinnerNumberModel(30, 1, 100, 1));
        formPanel.add(new JLabel("Capacidad:*"));
        formPanel.add(spinnerCapacity);

        // Combo para estado (solo en edición)
        comboStatus = new JComboBox<>(new String[]{"ACTIVE", "CLOSED", "CANCELLED"});
        if (isEditMode) {
            formPanel.add(new JLabel("Estado:"));
            formPanel.add(comboStatus);
        }

        add(formPanel, BorderLayout.CENTER);

        // Panel de información
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("* Campos obligatorios"));
        add(infoPanel, BorderLayout.NORTH);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = new JButton(isEditMode ? "Actualizar" : "Crear");
        JButton btnCancel = new JButton("Cancelar");

        btnSave.addActionListener(e -> saveSection());
        btnCancel.addActionListener(e -> dispose());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);

        add(buttonPanel, BorderLayout.SOUTH);

        // Si estamos editando, cargar datos existentes
        if (isEditMode) {
            loadSectionData();
        } else {
            // En modo creación, generar código automáticamente cuando se seleccione materia
            comboSubject.addActionListener(e -> generateSectionCode());
        }
    }

    private void loadSubjects() {
        List<Subject> subjects = subjectController.getAllActiveSubjects();
        comboSubject.removeAllItems();

        comboSubject.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Subject) {
                    Subject subject = (Subject) value;
                    setText(String.format("%s - %s", subject.getCode(), subject.getSubjectName()));
                }
                return this;
            }
        });

        for (Subject subject : subjects) {
            comboSubject.addItem(subject);
        }
    }

    private void loadProfessors() {
        // Aquí necesitarías un método para obtener profesores activos
        // Por ahora usamos datos de ejemplo
        comboProfessor.removeAllItems();

        comboProfessor.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index,
                                                          boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Professor) {
                    Professor professor = (Professor) value;
                    setText(String.format("%s %s - %s",
                            professor.getFirstName(),
                            professor.getLastName(),
                            professor.getDepartment()));
                }
                return this;
            }
        });

    }

    private void generateSectionCode() {
        if (!isEditMode && comboSubject.getSelectedItem() != null) {
            Subject selectedSubject = (Subject) comboSubject.getSelectedItem();
            // En una implementación real, esto calcularía el siguiente código disponible
            // Por ahora usamos "A" como predeterminado
            txtSectionCode.setText("A");
        }
    }

    private void loadSectionData() {
        if (existingSection != null) {
            // Seleccionar la materia correspondiente
            for (int i = 0; i < comboSubject.getItemCount(); i++) {
                Subject subject = comboSubject.getItemAt(i);
                if (subject.getSubjectId() == existingSection.getSubjectId()) {
                    comboSubject.setSelectedIndex(i);
                    break;
                }
            }

            txtSectionCode.setText(existingSection.getSectionCode());
            spinnerCapacity.setValue(existingSection.getCapacity());
            comboStatus.setSelectedItem(existingSection.getStatus());

            // Seleccionar el profesor correspondiente
            // Esto requeriría cargar los profesores desde la base de datos
        }
    }

    private void saveSection() {
        try {
            // Validar selección de materia
            if (comboSubject.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Seleccione una materia", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Subject selectedSubject = (Subject) comboSubject.getSelectedItem();

            // Validar campos obligatorios
            if (txtSectionCode.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Ingrese el código de sección", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (comboProfessor.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Seleccione un profesor", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Professor selectedProfessor = (Professor) comboProfessor.getSelectedItem();
            int capacity = (Integer) spinnerCapacity.getValue();

            boolean success;
            if (isEditMode) {
                success = sectionController.updateSection(
                        existingSection.getSectionId(),
                        selectedSubject.getSubjectId(),
                        txtSectionCode.getText().trim(),
                        selectedProfessor.getProfessorId(),
                        capacity,
                        existingSection.getCurrentEnrollment(),
                        (String) comboStatus.getSelectedItem()
                );
            } else {
                success = sectionController.createSection(
                        selectedSubject.getSubjectId(),
                        txtSectionCode.getText().trim(),
                        selectedProfessor.getProfessorId(),
                        capacity
                );
            }

            if (success) {
                dispose();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}