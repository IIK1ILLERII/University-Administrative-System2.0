package views;

import controller.SectionController;
import model.Section;
import javax.swing.*;
import java.awt.*;
import java.util.Optional;

public class SectionScheduleDialog extends JDialog {
    private JComboBox<String> comboDay;
    private JComboBox<String> comboStartTime;
    private JComboBox<String> comboEndTime;
    private JTextField txtClassroom;

    private SectionController controller;
    private int sectionId;

    public SectionScheduleDialog(Frame owner, SectionController controller, int sectionId) {
        super(owner, "Agregar Horario a Sección", true);
        this.controller = controller;
        this.sectionId = sectionId;
        initComponents();
        pack();
        setLocationRelativeTo(owner);
        setSize(400, 300);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        JPanel formPanel = new JPanel(new GridLayout(0, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Mostrar información de la sección
        Optional<Section> sectionOpt = controller.getSectionById(sectionId);
        if (sectionOpt.isPresent()) {
            Section section = sectionOpt.get();
            JLabel lblSectionInfo = new JLabel("Sección: " + section.getFullSectionCode());
            lblSectionInfo.setFont(lblSectionInfo.getFont().deriveFont(Font.BOLD));
            formPanel.add(new JLabel("Sección:"));
            formPanel.add(lblSectionInfo);
        }

        // Combo para días de la semana
        comboDay = new JComboBox<>(new String[]{"LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO"});
        formPanel.add(new JLabel("Día:*"));
        formPanel.add(comboDay);

        // Combos para horas
        comboStartTime = new JComboBox<>();
        comboEndTime = new JComboBox<>();
        loadTimeSlots();

        formPanel.add(new JLabel("Hora Inicio:*"));
        formPanel.add(comboStartTime);
        formPanel.add(new JLabel("Hora Fin:*"));
        formPanel.add(comboEndTime);

        // Campo para aula
        txtClassroom = new JTextField();
        formPanel.add(new JLabel("Aula:"));
        formPanel.add(txtClassroom);

        add(formPanel, BorderLayout.CENTER);

        // Panel de información
        JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        infoPanel.add(new JLabel("* Campos obligatorios"));
        add(infoPanel, BorderLayout.NORTH);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnSave = new JButton("Agregar Horario");
        JButton btnCancel = new JButton("Cancelar");

        btnSave.addActionListener(e -> saveSchedule());
        btnCancel.addActionListener(e -> dispose());

        buttonPanel.add(btnSave);
        buttonPanel.add(btnCancel);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadTimeSlots() {
        // Generar slots de tiempo de 8:00 a 22:00 en intervalos de 30 minutos
        for (int hour = 8; hour <= 22; hour++) {
            for (int minute = 0; minute < 60; minute += 30) {
                String time = String.format("%02d:%02d", hour, minute);
                comboStartTime.addItem(time);
                comboEndTime.addItem(time);
            }
        }

        // Establecer valores por defecto
        comboStartTime.setSelectedItem("08:00");
        comboEndTime.setSelectedItem("10:00");
    }

    private void saveSchedule() {
        try {
            // Validar campos obligatorios
            if (comboDay.getSelectedItem() == null || comboStartTime.getSelectedItem() == null ||
                    comboEndTime.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Complete todos los campos obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            boolean success = controller.addScheduleToSection(
                    sectionId,
                    (String) comboDay.getSelectedItem(),
                    (String) comboStartTime.getSelectedItem(),
                    (String) comboEndTime.getSelectedItem(),
                    txtClassroom.getText().trim()
            );

            if (success) {
                dispose();
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error al guardar: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}