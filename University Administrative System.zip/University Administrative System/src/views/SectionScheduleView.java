package views;

import controller.SectionController;
import model.Section;
import model.SectionSchedule;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SectionScheduleView extends JDialog {
    private JTable scheduleTable;
    private DefaultTableModel tableModel;
    private SectionController controller;

    public SectionScheduleView(Frame owner, SectionController controller) {
        super(owner, "Horarios de Todas las Secciones", true);
        this.controller = controller;
        initComponents();
        loadAllSchedules();
        pack();
        setLocationRelativeTo(owner);
        setSize(800, 600);
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Crear tabla para horarios
        tableModel = new DefaultTableModel();
        String[] columns = {"Sección", "Materia", "Profesor", "Día", "Horario", "Aula", "Inscritos"};
        for (String column : columns) {
            tableModel.addColumn(column);
        }

        scheduleTable = new JTable(tableModel);
        scheduleTable.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(scheduleTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Horarios de Secciones"));

        add(scrollPane, BorderLayout.CENTER);

        // Botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton btnRefresh = new JButton("🔄 Actualizar");
        JButton btnClose = new JButton("Cerrar");

        btnRefresh.addActionListener(e -> loadAllSchedules());
        btnClose.addActionListener(e -> dispose());

        buttonPanel.add(btnRefresh);
        buttonPanel.add(btnClose);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadAllSchedules() {
        tableModel.setRowCount(0);

        List<Section> sections = controller.getAllSections();
        for (Section section : sections) {
            for (SectionSchedule schedule : section.getSchedules()) {
                tableModel.addRow(new Object[]{
                        section.getFullSectionCode(),
                        section.getSubjectName(),
                        section.getProfessorName(),
                        schedule.getDayOfWeek(),
                        schedule.getTimeRange(),
                        schedule.getClassroom(),
                        section.getCurrentEnrollment() + "/" + section.getCapacity()
                });
            }

            // Si no tiene horarios, mostrar una fila indicándolo
            if (section.getSchedules().isEmpty()) {
                tableModel.addRow(new Object[]{
                        section.getFullSectionCode(),
                        section.getSubjectName(),
                        section.getProfessorName(),
                        "Sin horario",
                        "-",
                        "-",
                        section.getCurrentEnrollment() + "/" + section.getCapacity()
                });
            }
        }
    }
}