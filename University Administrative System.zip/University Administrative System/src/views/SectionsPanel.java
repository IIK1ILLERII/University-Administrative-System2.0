package views;

import controller.SectionController;
import controller.SubjectController;
import controller.ProfessorController;
import model.Section;
import model.Subject;
import model.Professor;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Optional;

public class SectionsPanel extends JPanel {
    private JTable sectionsTable, detailsTable, studentsTable;
    private DefaultTableModel sectionsModel, detailsModel, studentsModel;
    private JButton btnCreateSection, btnEditSection, btnDeleteSection, btnRefresh;
    private JButton btnViewSchedules, btnViewStudents, btnAddSchedule;
    private SectionController sectionController;
    private SubjectController subjectController;
    private ProfessorController professorController;
    private JTabbedPane tabbedPane;

    public SectionsPanel() {
        sectionController = new SectionController();
        subjectController = new SubjectController();
        professorController = new ProfessorController();
        initComponents();
        loadSections();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel superior con botones
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        btnCreateSection = new JButton("➕ Crear Sección");
        btnEditSection = new JButton("✏️ Editar Sección");
        btnDeleteSection = new JButton("🗑️ Eliminar Sección");
        btnAddSchedule = new JButton("⏰ Agregar Horario");
        btnViewSchedules = new JButton("📅 Ver Horarios");
        btnViewStudents = new JButton("👥 Ver Estudiantes");
        btnRefresh = new JButton("🔄 Actualizar");

        btnCreateSection.addActionListener(e -> showCreateSectionDialog());
        btnEditSection.addActionListener(e -> showEditSectionDialog());
        btnDeleteSection.addActionListener(e -> deleteSection());
        btnAddSchedule.addActionListener(e -> showAddScheduleDialog());
        btnViewSchedules.addActionListener(e -> showSchedulesTab());
        btnViewStudents.addActionListener(e -> showStudentsTab());
        btnRefresh.addActionListener(e -> refreshAll());

        topPanel.add(btnCreateSection);
        topPanel.add(btnEditSection);
        btnEditSection.setEnabled(false);
        topPanel.add(btnDeleteSection);
        btnDeleteSection.setEnabled(false);
        topPanel.add(btnAddSchedule);
        btnAddSchedule.setEnabled(false);
        topPanel.add(btnViewSchedules);
        btnViewSchedules.setEnabled(false);
        topPanel.add(btnViewStudents);
        btnViewStudents.setEnabled(false);
        topPanel.add(btnRefresh);

        add(topPanel, BorderLayout.NORTH);

        // Crear pestañas principales
        tabbedPane = new JTabbedPane();

        // Pestaña 1: Lista de Secciones
        sectionsModel = new DefaultTableModel();
        String[] sectionColumns = {
                "ID", "Código", "Materia", "Profesor", "Inscritos", "Horarios", "Estado"
        };
        for (String column : sectionColumns) {
            sectionsModel.addColumn(column);
        }
        sectionsTable = new JTable(sectionsModel);
        sectionsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        sectionsTable.getSelectionModel().addListSelectionListener(e -> updateButtonStates());

        JScrollPane sectionsScroll = new JScrollPane(sectionsTable);
        sectionsScroll.setBorder(BorderFactory.createTitledBorder("Lista de Secciones"));
        tabbedPane.addTab("🏫 Secciones", sectionsScroll);

        // Pestaña 2: Horarios de Sección
        detailsModel = new DefaultTableModel();
        String[] detailColumns = {"Día", "Horario", "Aula"};
        for (String column : detailColumns) {
            detailsModel.addColumn(column);
        }
        detailsTable = new JTable(detailsModel);
        JScrollPane detailsScroll = new JScrollPane(detailsTable);
        detailsScroll.setBorder(BorderFactory.createTitledBorder("Horarios de la Sección"));
        tabbedPane.addTab("📅 Horarios", detailsScroll);

        // Pestaña 3: Estudiantes Inscritos
        studentsModel = new DefaultTableModel();
        String[] studentColumns = {"ID", "Nombre", "Email", "Carrera", "Semestre"};
        for (String column : studentColumns) {
            studentsModel.addColumn(column);
        }
        studentsTable = new JTable(studentsModel);
        JScrollPane studentsScroll = new JScrollPane(studentsTable);
        studentsScroll.setBorder(BorderFactory.createTitledBorder("Estudiantes Inscritos"));
        tabbedPane.addTab("👥 Estudiantes", studentsScroll);

        add(tabbedPane, BorderLayout.CENTER);
        add(createStatsPanel(), BorderLayout.SOUTH);
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Estadísticas"));

        int totalSections = sectionController.getTotalSections();
        int activeSections = 0; // Podrías calcular esto
        int totalStudents = 0; // Podrías calcular esto

        JLabel lblSections = new JLabel("Total Secciones: " + totalSections);
        JLabel lblActive = new JLabel("Activas: " + activeSections);
        JLabel lblStudents = new JLabel("Estudiantes: " + totalStudents);

        statsPanel.add(lblSections);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblActive);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblStudents);

        return statsPanel;
    }

    private void updateButtonStates() {
        int selectedRow = sectionsTable.getSelectedRow();
        boolean hasSelection = selectedRow != -1;

        btnEditSection.setEnabled(hasSelection);
        btnDeleteSection.setEnabled(hasSelection);
        btnAddSchedule.setEnabled(hasSelection);
        btnViewSchedules.setEnabled(hasSelection);
        btnViewStudents.setEnabled(hasSelection);
    }

    public void loadSections() {
        sectionController.loadSectionsToTable(sectionsTable);
    }

    private void loadSectionDetails() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow != -1) {
            int sectionId = (int) sectionsModel.getValueAt(selectedRow, 0);
            sectionController.loadSectionDetailsToTable(detailsTable, sectionId);
        }
    }

    private void loadEnrolledStudents() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow != -1) {
            int sectionId = (int) sectionsModel.getValueAt(selectedRow, 0);
            sectionController.loadEnrolledStudentsToTable(studentsTable, sectionId);
        }
    }

    private void refreshAll() {
        loadSections();
        loadSectionDetails();
        loadEnrolledStudents();
        updateButtonStates();
    }

    private void showCreateSectionDialog() {
        SectionDialog dialog = new SectionDialog(
                (Frame) SwingUtilities.getWindowAncestor(this),
                sectionController, subjectController, professorController);
        dialog.setVisible(true);
        refreshAll();
    }

    private void showEditSectionDialog() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow == -1) return;

        int sectionId = (int) sectionsModel.getValueAt(selectedRow, 0);
        Optional<Section> sectionOpt = sectionController.getSectionById(sectionId);

        if (sectionOpt.isPresent()) {
            SectionDialog dialog = new SectionDialog(
                    (Frame) SwingUtilities.getWindowAncestor(this),
                    sectionController, subjectController, professorController, sectionOpt.get());
            dialog.setVisible(true);
            refreshAll();
        }
    }

    private void deleteSection() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow == -1) return;

        int sectionId = (int) sectionsModel.getValueAt(selectedRow, 0);
        boolean success = sectionController.deleteSection(sectionId);

        if (success) {
            refreshAll();
        }
    }

    private void showAddScheduleDialog() {
        int selectedRow = sectionsTable.getSelectedRow();
        if (selectedRow == -1) return;

        int sectionId = (int) sectionsModel.getValueAt(selectedRow, 0);
        SectionScheduleDialog dialog = new SectionScheduleDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), sectionController, sectionId);
        dialog.setVisible(true);
        refreshAll();
    }

    private void showSchedulesTab() {
        tabbedPane.setSelectedIndex(1);
        loadSectionDetails();
    }

    private void showStudentsTab() {
        tabbedPane.setSelectedIndex(2);
        loadEnrolledStudents();
    }
}