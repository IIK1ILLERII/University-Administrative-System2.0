package views;

import controller.SubjectController;
import model.Subject;
import model.ClassSchedule;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.Optional;

public class SubjectsPanel extends JPanel {
    private JTable subjectsTable, schedulesTable;
    private DefaultTableModel subjectsModel, schedulesModel;
    private JButton btnAddSubject, btnEditSubject, btnDeleteSubject, btnRefresh;
    private JButton btnAddSchedule, btnEditSchedule, btnDeleteSchedule, btnViewWeekly;
    private SubjectController subjectController;
    private JTabbedPane tabbedPane;

    public SubjectsPanel() {
        subjectController = new SubjectController();
        initComponents();
        loadSubjects();
        loadWeeklySchedule();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Panel superior con botones
        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));

        // Botones para materias
        btnAddSubject = new JButton("➕ Agregar Materia");
        btnEditSubject = new JButton("✏️ Editar Materia");
        btnDeleteSubject = new JButton("🗑️ Eliminar Materia");
        btnRefresh = new JButton("🔄 Actualizar");

        btnAddSubject.addActionListener(e -> showAddSubjectDialog());
        btnEditSubject.addActionListener(e -> showEditSubjectDialog());
        btnDeleteSubject.addActionListener(e -> deleteSubject());
        btnRefresh.addActionListener(e -> refreshAll());

        topPanel.add(btnAddSubject);
        topPanel.add(btnEditSubject);
        topPanel.add(btnDeleteSubject);

        // Separador
        topPanel.add(Box.createHorizontalStrut(20));

        // Botones para horarios
        btnAddSchedule = new JButton("⏰ Agregar Horario");
        btnEditSchedule = new JButton("📅 Editar Horario");
        btnDeleteSchedule = new JButton("❌ Eliminar Horario");
        btnViewWeekly = new JButton("📊 Vista Semanal");

        btnAddSchedule.addActionListener(e -> showAddScheduleDialog());
        btnEditSchedule.addActionListener(e -> showEditScheduleDialog());
        btnDeleteSchedule.addActionListener(e -> deleteSchedule());
        btnViewWeekly.addActionListener(e -> showWeeklyScheduleView());

        topPanel.add(btnAddSchedule);
        topPanel.add(btnEditSchedule);
        topPanel.add(btnDeleteSchedule);
        topPanel.add(btnViewWeekly);
        topPanel.add(btnRefresh);

        add(topPanel, BorderLayout.NORTH);

        // Crear pestañas
        tabbedPane = new JTabbedPane();

        // Pestaña 1: Lista de Materias
        subjectsModel = new DefaultTableModel();
        String[] subjectColumns = {
                "ID", "Código", "Nombre", "Créditos", "Profesor",
                "Departamento", "Dificultad", "Horas/Semana", "Horarios"
        };
        for (String column : subjectColumns) {
            subjectsModel.addColumn(column);
        }
        subjectsTable = new JTable(subjectsModel);
        subjectsTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane subjectsScroll = new JScrollPane(subjectsTable);
        subjectsScroll.setBorder(BorderFactory.createTitledBorder("Lista de Materias"));
        tabbedPane.addTab("📚 Materias", subjectsScroll);

        // Pestaña 2: Horarios Semanales
        schedulesModel = new DefaultTableModel();
        String[] scheduleColumns = {
                "ID", "Código", "Materia", "Profesor", "Día",
                "Horario", "Aula", "Estado"
        };
        for (String column : scheduleColumns) {
            schedulesModel.addColumn(column);
        }
        schedulesTable = new JTable(schedulesModel);
        schedulesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane schedulesScroll = new JScrollPane(schedulesTable);
        schedulesScroll.setBorder(BorderFactory.createTitledBorder("Horarios Semanales"));
        tabbedPane.addTab("📅 Horarios", schedulesScroll);

        add(tabbedPane, BorderLayout.CENTER);
        add(createStatsPanel(), BorderLayout.SOUTH);
    }

    private JPanel createStatsPanel() {
        JPanel statsPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        statsPanel.setBorder(BorderFactory.createTitledBorder("Estadísticas"));

        int totalSubjects = subjectController.getTotalSubjects();
        int totalSchedules = subjectController.getTotalSchedules();
        int basicSubjects = subjectController.getBasicSubjects().size();
        int intermediateSubjects = subjectController.getIntermediateSubjects().size();
        int advancedSubjects = subjectController.getAdvancedSubjects().size();

        JLabel lblSubjects = new JLabel("Materias: " + totalSubjects);
        JLabel lblSchedules = new JLabel("Horarios: " + totalSchedules);
        JLabel lblBasic = new JLabel("Básicas: " + basicSubjects);
        JLabel lblIntermediate = new JLabel("Intermedias: " + intermediateSubjects);
        JLabel lblAdvanced = new JLabel("Avanzadas: " + advancedSubjects);

        statsPanel.add(lblSubjects);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblSchedules);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblBasic);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblIntermediate);
        statsPanel.add(Box.createHorizontalStrut(10));
        statsPanel.add(lblAdvanced);

        return statsPanel;
    }

    public void loadSubjects() {
        subjectController.loadSubjectsToTable(subjectsTable);
    }

    public void loadWeeklySchedule() {
        subjectController.loadSchedulesToTable(schedulesTable);
    }

    private void refreshAll() {
        loadSubjects();
        loadWeeklySchedule();
        revalidate();
        repaint();
    }

    private void showAddSubjectDialog() {
        // Tu código existente para agregar materia
        // ... (mantener el código original)
    }

    private void showEditSubjectDialog() {
        // Tu código existente para editar materia
        // ... (mantener el código original)
    }

    private void deleteSubject() {
        // Tu código existente para eliminar materia
        // ... (mantener el código original)
    }

    private void showAddScheduleDialog() {
        ScheduleDialog dialog = new ScheduleDialog((Frame) SwingUtilities.getWindowAncestor(this), subjectController);
        dialog.setVisible(true);
        refreshAll();
    }

    private void showEditScheduleDialog() {
        int selectedRow = schedulesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un horario para editar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int scheduleId = (int) schedulesModel.getValueAt(selectedRow, 0);
        Optional<ClassSchedule> scheduleOpt = subjectController.getScheduleById(scheduleId);

        if (scheduleOpt.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo cargar los datos del horario", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        ScheduleDialog dialog = new ScheduleDialog((Frame) SwingUtilities.getWindowAncestor(this),
                subjectController, scheduleOpt.get());
        dialog.setVisible(true);
        refreshAll();
    }

    private void deleteSchedule() {
        int selectedRow = schedulesTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this,
                    "Seleccione un horario para eliminar", "Advertencia", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int scheduleId = (int) schedulesModel.getValueAt(selectedRow, 0);
        boolean success = subjectController.deleteSchedule(scheduleId);

        if (success) {
            refreshAll();
        }
    }

    private void showWeeklyScheduleView() {
        WeeklyScheduleDialog dialog = new WeeklyScheduleDialog(
                (Frame) SwingUtilities.getWindowAncestor(this), subjectController);
        dialog.setVisible(true);
    }
}