package views;

import controller.SubjectController;
import model.ClassSchedule;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class WeeklyScheduleDialog extends JDialog {
    private SubjectController controller;
    private JTable weeklyTable;
    private DefaultTableModel weeklyModel;

    public WeeklyScheduleDialog(Frame owner, SubjectController controller) {
        super(owner, "Vista Semanal de Horarios", true);
        this.controller = controller;
        initComponents();
        pack();
        setLocationRelativeTo(owner);
        setSize(800, 600);
        loadWeeklySchedule();
    }

    private void initComponents() {
        setLayout(new BorderLayout(10, 10));

        // Crear tabla para vista semanal
        weeklyModel = new DefaultTableModel();
        String[] days = {"Hora", "LUNES", "MARTES", "MIERCOLES", "JUEVES", "VIERNES", "SABADO"};
        for (String day : days) {
            weeklyModel.addColumn(day);
        }

        // Llenar con horas
        for (int hour = 8; hour <= 22; hour++) {
            for (int minute = 0; minute < 60; minute += 60) {
                String time = String.format("%02d:%02d", hour, minute);
                weeklyModel.addRow(new Object[]{time, "", "", "", "", "", ""});
            }
        }

        weeklyTable = new JTable(weeklyModel);
        weeklyTable.setRowHeight(60);
        weeklyTable.setEnabled(false); // Solo para visualización

        JScrollPane scrollPane = new JScrollPane(weeklyTable);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Horario Semanal"));

        add(scrollPane, BorderLayout.CENTER);

        // Botón cerrar
        JPanel buttonPanel = new JPanel();
        JButton btnClose = new JButton("Cerrar");
        btnClose.addActionListener(e -> dispose());
        buttonPanel.add(btnClose);

        add(buttonPanel, BorderLayout.SOUTH);
    }

    private void loadWeeklySchedule() {
        List<ClassSchedule> schedules = controller.getWeeklySchedule();

        for (ClassSchedule schedule : schedules) {
            int dayColumn = getDayColumn(schedule.getDayOfWeek());
            if (dayColumn != -1) {
                int row = getTimeRow(schedule.getStartTime());
                if (row != -1) {
                    String cellText = String.format("<html><b>%s</b><br/>%s<br/>Aula: %s<br/>Prof: %s</html>",
                            schedule.getSubjectName(),
                            schedule.getTimeRange(),
                            schedule.getClassroom(),
                            schedule.getProfessorName());

                    weeklyModel.setValueAt(cellText, row, dayColumn);
                }
            }
        }
    }

    private int getDayColumn(String day) {
        switch (day) {
            case "LUNES": return 1;
            case "MARTES": return 2;
            case "MIERCOLES": return 3;
            case "JUEVES": return 4;
            case "VIERNES": return 5;
            case "SABADO": return 6;
            default: return -1;
        }
    }

    private int getTimeRow(String time) {
        String[] parts = time.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        int row = (hour - 8) * 2; // 2 filas por hora (00 y 30)
        if (minute == 30) row += 1;

        return row >= 0 && row < weeklyModel.getRowCount() ? row : -1;
    }
}